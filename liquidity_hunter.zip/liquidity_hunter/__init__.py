"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                         LIQUIDITY HUNTER MODULE                                ║
║                                                                                ║
║  Data-driven liquidity sweep detection with ML quality prediction              ║
║  Follow the whale footprints + ML to filter high-quality sweeps                ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

from .liquidity_hunter import (
    normalize_columns,
    find_liquidity_levels,
    detect_sweep,
    check_approaching_liquidity,
    get_binance_liquidations,
    estimate_liquidation_zones,
    generate_liquidity_trade_plan,
    scan_for_liquidity_setups,
    full_liquidity_analysis
)

# Core UI imports (always available)
from .liquidity_hunter_ui import (
    render_liquidity_header,
    render_liquidity_map,
    render_sweep_status,
    render_approaching_levels,
    render_trade_plan,
    render_whale_positioning,
    render_scanner_results,
    render_liquidity_education,
    render_scanner_controls,
    filter_scanner_results,
    render_ml_training_panel,
    render_ml_prediction_badge
)

# NEW: Improved sequence visualization (optional - may not exist in older versions)
try:
    from .liquidity_hunter_ui import (
        render_liquidity_sequence,
        render_next_targets_improved
    )
except ImportError:
    # Fallback stub functions
    def render_liquidity_sequence(analysis: dict):
        """Stub - update liquidity_hunter_ui.py to get this feature"""
        import streamlit as st
        st.info("Update liquidity_hunter_ui.py to enable sequence visualization")
    
    def render_next_targets_improved(analysis: dict):
        """Stub - update liquidity_hunter_ui.py to get this feature"""
        import streamlit as st
        st.info("Update liquidity_hunter_ui.py to enable improved targets")

# Liquidity Sequence Visualization (pure Streamlit - optional)
try:
    from .liquidity_sequence import (
        render_full_liquidity_sequence,
        render_sequence_diagram_st,
        render_actionable_summary_st,
        render_expected_sequence_st,
        analyze_liquidity_sequence
    )
except ImportError:
    # Fallback - these features just won't be available
    render_full_liquidity_sequence = None
    analyze_liquidity_sequence = None

# ML module (optional)
try:
    from .liquidity_hunter_ml import (
        predict_sweep_quality,
        store_sweep_trade,
        get_training_stats,
        get_predictor,
        get_model_status,
        SweepPredictor,
        generate_training_from_history,
        bulk_generate_training_data,
        # Stock functions
        get_stock_institutional_score,
        generate_training_from_history_stock,
        bulk_generate_training_data_stock,
        # ETF functions
        generate_training_from_history_etf,
        bulk_generate_training_data_etf,
        init_db
    )
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False

__all__ = [
    # Core functions
    'normalize_columns',
    'find_liquidity_levels',
    'detect_sweep',
    'check_approaching_liquidity',
    'get_binance_liquidations',
    'estimate_liquidation_zones',
    'generate_liquidity_trade_plan',
    'scan_for_liquidity_setups',
    'full_liquidity_analysis',
    # UI functions
    'render_liquidity_header',
    'render_liquidity_map',
    'render_sweep_status',
    'render_approaching_levels',
    'render_trade_plan',
    'render_whale_positioning',
    'render_scanner_results',
    'render_liquidity_education',
    # NEW: Improved sequence visualization
    'render_liquidity_sequence',
    'render_next_targets_improved'
]
