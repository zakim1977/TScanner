"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                         LIQUIDITY HUNTER MODULE                                ║
║                                                                                ║
║  Data-driven liquidity sweep detection with ML quality prediction              ║
║  Follow the whale footprints + ML to filter high-quality sweeps                ║
║                                                                                ║
║  Strategy:                                                                     ║
║  1. Identify where stops cluster (liquidity pools)                             ║
║  2. Wait for price to sweep them (the hunt)                                    ║
║  3. ML predicts sweep quality (probability of TP1 before SL)                   ║
║  4. Enter when price rejects + ML confirms (whale entry)                       ║
║  5. Exit into liquidation cascade (forced covering)                            ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import requests

# Try to import ML module
try:
    from .liquidity_hunter_ml import predict_sweep_quality, store_sweep_trade, get_training_stats
    LH_ML_AVAILABLE = True
    print("[LH] ML module loaded")
except ImportError:
    try:
        from liquidity_hunter_ml import predict_sweep_quality, store_sweep_trade, get_training_stats
        LH_ML_AVAILABLE = True
        print("[LH] ML module loaded (direct import)")
    except ImportError:
        LH_ML_AVAILABLE = False
        print("[LH] ML module not available - using rule-based only")


# ═══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize DataFrame column names to lowercase.
    Handles both 'High'/'Low'/'Close' and 'high'/'low'/'close' formats.
    """
    if df is None:
        return None
    
    # Create a copy to avoid modifying original
    df = df.copy()
    
    # Normalize column names to lowercase
    df.columns = [col.lower() for col in df.columns]
    
    return df


# ═══════════════════════════════════════════════════════════════════════════════
# LIQUIDITY LEVEL DETECTION
# ═══════════════════════════════════════════════════════════════════════════════

def find_liquidity_levels(df: pd.DataFrame, lookback: int = 50) -> Dict:
    """
    Find key liquidity levels where stops likely cluster.
    These are swing highs/lows that haven't been swept yet.
    """
    if df is None or len(df) < lookback:
        return {'lows': [], 'highs': [], 'equal_lows': [], 'equal_highs': []}
    
    # Normalize column names
    df = normalize_columns(df)
    
    highs = df['high'].values
    lows = df['low'].values
    closes = df['close'].values
    
    swing_lows = []
    swing_highs = []
    
    # Find swing points (local min/max)
    for i in range(5, len(df) - 1):
        # Swing Low: lower than 5 candles before and after
        if lows[i] == min(lows[i-5:i+6]):
            swing_lows.append({
                'price': float(lows[i]),
                'index': i,
                'timestamp': df.index[i] if hasattr(df.index[i], 'strftime') else str(df.index[i]),
                'swept': False,
                'strength': 'STRONG' if lows[i] == min(lows[max(0,i-20):min(len(lows),i+20)]) else 'MODERATE'
            })
        
        # Swing High: higher than 5 candles before and after
        if highs[i] == max(highs[i-5:i+6]):
            swing_highs.append({
                'price': float(highs[i]),
                'index': i,
                'timestamp': df.index[i] if hasattr(df.index[i], 'strftime') else str(df.index[i]),
                'swept': False,
                'strength': 'STRONG' if highs[i] == max(highs[max(0,i-20):min(len(highs),i+20)]) else 'MODERATE'
            })
    
    # Check if levels have been swept
    current_price = closes[-1]
    current_low = lows[-1]
    current_high = highs[-1]
    
    for level in swing_lows:
        # Swept if price went below it after it formed
        later_lows = lows[level['index']+1:]
        if len(later_lows) > 0 and min(later_lows) < level['price']:
            level['swept'] = True
            # Track HOW RECENTLY it was swept (index of the sweep candle)
            sweep_idx = level['index'] + 1 + np.argmin(later_lows)
            level['swept_candles_ago'] = len(lows) - sweep_idx
    
    for level in swing_highs:
        later_highs = highs[level['index']+1:]
        if len(later_highs) > 0 and max(later_highs) > level['price']:
            level['swept'] = True
            sweep_idx = level['index'] + 1 + np.argmax(later_highs)
            level['swept_candles_ago'] = len(highs) - sweep_idx
    
    # Find Equal Lows/Highs (double/triple bottoms/tops = MAJOR liquidity)
    equal_lows = find_equal_levels(swing_lows, threshold_pct=0.3)
    equal_highs = find_equal_levels(swing_highs, threshold_pct=0.3)
    
    # Include BOTH unswept AND recently swept levels
    # Unswept = potential targets
    # Recently swept (within 50 candles) + price back above = potential ENTRY
    unswept_lows = [l for l in swing_lows if not l.get('swept')]
    recently_swept_lows = [l for l in swing_lows if l.get('swept') and l.get('swept_candles_ago', 999) <= 50]
    
    unswept_highs = [h for h in swing_highs if not h.get('swept')]
    recently_swept_highs = [h for h in swing_highs if h.get('swept') and h.get('swept_candles_ago', 999) <= 50]
    
    # Sort by distance from current price
    unswept_lows.sort(key=lambda x: abs(x['price'] - current_price))
    unswept_highs.sort(key=lambda x: abs(x['price'] - current_price))
    recently_swept_lows.sort(key=lambda x: x.get('swept_candles_ago', 999))
    recently_swept_highs.sort(key=lambda x: x.get('swept_candles_ago', 999))
    
    return {
        'lows': unswept_lows[:10],  # Unswept = targets
        'highs': unswept_highs[:10],
        'recently_swept_lows': recently_swept_lows[:5],  # Recently swept = potential entries
        'recently_swept_highs': recently_swept_highs[:5],
        'equal_lows': equal_lows,
        'equal_highs': equal_highs,
        'current_price': float(current_price)
    }


def find_equal_levels(levels: List[Dict], threshold_pct: float = 0.3) -> List[Dict]:
    """
    Find equal highs/lows (multiple touches at same level).
    These are HIGH PROBABILITY liquidity pools.
    """
    if len(levels) < 2:
        return []
    
    equal_levels = []
    used_indices = set()
    
    for i, level1 in enumerate(levels):
        if i in used_indices:
            continue
            
        cluster = [level1]
        
        for j, level2 in enumerate(levels[i+1:], i+1):
            if j in used_indices:
                continue
            
            # Check if prices are within threshold
            pct_diff = abs(level1['price'] - level2['price']) / level1['price'] * 100
            if pct_diff < threshold_pct:
                cluster.append(level2)
                used_indices.add(j)
        
        if len(cluster) >= 2:
            used_indices.add(i)
            avg_price = sum(l['price'] for l in cluster) / len(cluster)
            equal_levels.append({
                'price': avg_price,
                'touches': len(cluster),
                'levels': cluster,
                'strength': 'MAJOR' if len(cluster) >= 3 else 'STRONG',
                'swept': any(l['swept'] for l in cluster)
            })
    
    return [l for l in equal_levels if not l['swept']]


# ═══════════════════════════════════════════════════════════════════════════════
# SWEEP DETECTION
# ═══════════════════════════════════════════════════════════════════════════════

def detect_sweep(df: pd.DataFrame, liquidity_levels: Dict, atr: float, lookback_candles: int = 25, whale_pct: float = 50) -> Dict:
    """
    Detect if price has recently swept a liquidity level.
    
    PRIORITY ORDER:
    1. Check RECENTLY SWEPT liquidity levels FIRST (these are the real pools!)
    2. Only if none found, check unswept levels for fresh sweeps
    
    This ensures we detect the $87,263 level (marked "SWEEP FOR LONG") 
    instead of random swing lows like $87,895.
    """
    if df is None or len(df) < 20:
        return {'detected': False}
    
    df = normalize_columns(df)
    
    current_price = float(df['close'].iloc[-1])
    lows = df['low'].values
    highs = df['high'].values
    volumes = df['volume'].values
    avg_volume = float(df['volume'].rolling(20).mean().iloc[-1])
    
    lookback = min(lookback_candles, len(df) - 10)
    
    long_sweep = None
    short_sweep = None
    
    # DEBUG: Show what liquidity levels we have
    recently_swept_lows = liquidity_levels.get('recently_swept_lows', [])
    recently_swept_highs = liquidity_levels.get('recently_swept_highs', [])
    lows_list = liquidity_levels.get('lows', [])
    highs_list = liquidity_levels.get('highs', [])
    
    print(f"[SWEEP_DEBUG] RECENTLY SWEPT LOWS: {[(round(l.get('price', 0), 2), l.get('swept_candles_ago', '?')) for l in recently_swept_lows[:5]]}")
    print(f"[SWEEP_DEBUG] RECENTLY SWEPT HIGHS: {[(round(h.get('price', 0), 2), h.get('swept_candles_ago', '?')) for h in recently_swept_highs[:5]]}")
    print(f"[SWEEP_DEBUG] Unswept LOWS: {[round(l.get('price', 0), 2) for l in lows_list[:5]]}")
    print(f"[SWEEP_DEBUG] Unswept HIGHS: {[round(h.get('price', 0), 2) for h in highs_list[:5]]}")
    
    # ═══════════════════════════════════════════════════════════════════════
    # PRIORITY 1: Check RECENTLY SWEPT liquidity levels FIRST!
    # These are the real pools shown in Liquidity Map as "SWEEP FOR LONG/SHORT"
    # ═══════════════════════════════════════════════════════════════════════
    
    for level in recently_swept_lows:
        level_price = level.get('price')
        candles_ago = level.get('swept_candles_ago', 999)
        
        if level_price and level_price > 0 and candles_ago <= lookback:
            # Price must be ABOVE the level now (confirmed reversal)
            if current_price > level_price:
                confidence = 80  # High confidence for real liquidity pools
                if candles_ago <= 5:
                    confidence += 10
                if level.get('strength') == 'STRONG':
                    confidence += 5
                
                if long_sweep is None or candles_ago < long_sweep['candles_ago']:
                    long_sweep = {
                        'detected': True,
                        'type': 'SWEEP_LOW',
                        'direction': 'LONG',
                        'level_swept': float(level_price),
                        'current_price': current_price,
                        'candles_ago': candles_ago,
                        'distance_pct': abs(level_price - current_price) / current_price * 100,
                        'volume_confirmed': False,
                        'confidence': min(95, confidence),
                        'source': 'liquidity_pool'
                    }
    
    for level in recently_swept_highs:
        level_price = level.get('price')
        candles_ago = level.get('swept_candles_ago', 999)
        
        if level_price and level_price > 0 and candles_ago <= lookback:
            # Price must be BELOW the level now (confirmed reversal)
            if current_price < level_price:
                confidence = 80
                if candles_ago <= 5:
                    confidence += 10
                if level.get('strength') == 'STRONG':
                    confidence += 5
                
                if short_sweep is None or candles_ago < short_sweep['candles_ago']:
                    short_sweep = {
                        'detected': True,
                        'type': 'SWEEP_HIGH',
                        'direction': 'SHORT',
                        'level_swept': float(level_price),
                        'current_price': current_price,
                        'candles_ago': candles_ago,
                        'distance_pct': abs(level_price - current_price) / current_price * 100,
                        'volume_confirmed': False,
                        'confidence': min(95, confidence),
                        'source': 'liquidity_pool'
                    }
    
    # ═══════════════════════════════════════════════════════════════════════
    # PRIORITY 2: Check UNSWEPT levels for fresh sweeps (only if Priority 1 found nothing)
    # ═══════════════════════════════════════════════════════════════════════
    
    if long_sweep is None:
        for level in lows_list:
            level_price = level.get('price')
            if not level_price or level_price <= 0 or current_price <= level_price:
                continue
            
            # Check if any recent candle swept this level
            for j in range(1, lookback + 1):
                recent_idx = len(df) - j
                if recent_idx < 0:
                    break
                
                if float(lows[recent_idx]) < level_price:
                    volume_confirmed = float(volumes[recent_idx]) > avg_volume * 1.3
                    confidence = 70 + (15 if j <= 5 else 5) + (5 if volume_confirmed else 0)
                    
                    long_sweep = {
                        'detected': True,
                        'type': 'SWEEP_LOW',
                        'direction': 'LONG',
                        'level_swept': float(level_price),
                        'current_price': current_price,
                        'candles_ago': j,
                        'distance_pct': abs(level_price - current_price) / current_price * 100,
                        'volume_confirmed': volume_confirmed,
                        'confidence': min(95, confidence),
                        'source': 'unswept_pool'
                    }
                    break
            if long_sweep:
                break
    
    if short_sweep is None:
        for level in highs_list:
            level_price = level.get('price')
            if not level_price or level_price <= 0 or current_price >= level_price:
                continue
            
            for j in range(1, lookback + 1):
                recent_idx = len(df) - j
                if recent_idx < 0:
                    break
                
                if float(highs[recent_idx]) > level_price:
                    volume_confirmed = float(volumes[recent_idx]) > avg_volume * 1.3
                    confidence = 70 + (15 if j <= 5 else 5) + (5 if volume_confirmed else 0)
                    
                    short_sweep = {
                        'detected': True,
                        'type': 'SWEEP_HIGH',
                        'direction': 'SHORT',
                        'level_swept': float(level_price),
                        'current_price': current_price,
                        'candles_ago': j,
                        'distance_pct': abs(level_price - current_price) / current_price * 100,
                        'volume_confirmed': volume_confirmed,
                        'confidence': min(95, confidence),
                        'source': 'unswept_pool'
                    }
                    break
            if short_sweep:
                break
    
    # ═══════════════════════════════════════════════════════════════════════
    # DEBUG output
    # ═══════════════════════════════════════════════════════════════════════
    print(f"[SWEEP_DEBUG] Current price: ${current_price:,.2f}")
    if long_sweep:
        print(f"[SWEEP_DEBUG] LONG: ${long_sweep['level_swept']:,.2f}, {long_sweep['candles_ago']} ago, source={long_sweep.get('source')}")
    else:
        print(f"[SWEEP_DEBUG] No LONG sweep")
    if short_sweep:
        print(f"[SWEEP_DEBUG] SHORT: ${short_sweep['level_swept']:,.2f}, {short_sweep['candles_ago']} ago, source={short_sweep.get('source')}")
    else:
        print(f"[SWEEP_DEBUG] No SHORT sweep")
    
    # ═══════════════════════════════════════════════════════════════════════
    # Pick the BEST sweep
    # ═══════════════════════════════════════════════════════════════════════
    if long_sweep and short_sweep:
        # Most recent wins
        if long_sweep['candles_ago'] < short_sweep['candles_ago']:
            print(f"[SWEEP_DEBUG] → LONG more recent")
            return long_sweep
        elif short_sweep['candles_ago'] < long_sweep['candles_ago']:
            print(f"[SWEEP_DEBUG] → SHORT more recent")
            return short_sweep
        else:
            # Tiebreaker: whale alignment
            if whale_pct > 55:
                print(f"[SWEEP_DEBUG] → Whale bullish, LONG")
                return long_sweep
            elif whale_pct < 45:
                print(f"[SWEEP_DEBUG] → Whale bearish, SHORT")
                return short_sweep
            else:
                result = long_sweep if long_sweep['distance_pct'] < short_sweep['distance_pct'] else short_sweep
                print(f"[SWEEP_DEBUG] → Neutral, closer: {result['direction']}")
                return result
    
    if long_sweep:
        print(f"[SWEEP_DEBUG] → Returning LONG")
        return long_sweep
    if short_sweep:
        print(f"[SWEEP_DEBUG] → Returning SHORT")
        return short_sweep
    
    print(f"[SWEEP_DEBUG] → No sweep detected")
    return {'detected': False}


def calculate_sweep_confidence(swept: bool, rejected: bool, volume_spike: bool, 
                                good_close: bool, strength: str) -> int:
    """Calculate confidence score for a sweep (0-100)"""
    confidence = 0
    
    if swept and rejected:
        confidence += 40  # Base for sweep + rejection
    
    if volume_spike:
        confidence += 20  # Volume confirmation
    
    if good_close:
        confidence += 15  # Close position confirms
    
    if strength == 'STRONG':
        confidence += 15
    elif strength == 'MAJOR':
        confidence += 25
    else:
        confidence += 10
    
    return min(confidence, 100)


# ═══════════════════════════════════════════════════════════════════════════════
# APPROACHING LIQUIDITY DETECTION
# ═══════════════════════════════════════════════════════════════════════════════

def check_approaching_liquidity(current_price: float, liquidity_levels: Dict, 
                                  atr: float) -> Dict:
    """
    Check if price is approaching a liquidity level (pre-sweep setup).
    
    Shows NEXT TARGETS for potential entries:
    - Lows below current price → If swept = LONG entry
    - Highs above current price → If swept = SHORT entry
    
    Only shows UNSWEPT levels (fresh targets).
    """
    approaching = []
    
    # Check lows below current price (NEXT LONG targets)
    for level in liquidity_levels.get('lows', []):
        distance = current_price - level['price']
        distance_atr = distance / atr
        
        if 0 < distance_atr < 5:  # Within 5 ATR
            # Calculate how old this level is (candles since it formed)
            level_age = level.get('index', 0)  # Index in the dataframe
            
            approaching.append({
                'type': 'LOW',
                'price': level['price'],
                'distance': distance,
                'distance_atr': distance_atr,
                'strength': level.get('strength', 'MODERATE'),
                'direction_after_sweep': 'LONG',
                'proximity': 'IMMINENT' if distance_atr < 1 else 'CLOSE' if distance_atr < 2 else 'APPROACHING',
                'status': 'UNSWEPT',  # Fresh target
                'candle_index': level_age,  # When it formed (index in df)
                'formed_ago': f"~{200 - level_age} candles ago" if level_age > 0 else "recent"
            })
    
    # Check highs above current price (NEXT SHORT targets)
    for level in liquidity_levels.get('highs', []):
        distance = level['price'] - current_price
        distance_atr = distance / atr
        
        if 0 < distance_atr < 5:
            level_age = level.get('index', 0)
            
            approaching.append({
                'type': 'HIGH',
                'price': level['price'],
                'distance': distance,
                'distance_atr': distance_atr,
                'strength': level.get('strength', 'MODERATE'),
                'direction_after_sweep': 'SHORT',
                'proximity': 'IMMINENT' if distance_atr < 1 else 'CLOSE' if distance_atr < 2 else 'APPROACHING',
                'status': 'UNSWEPT',
                'candle_index': level_age,
                'formed_ago': f"~{200 - level_age} candles ago" if level_age > 0 else "recent"
            })
    
    # Check equal lows/highs (higher priority - MAJOR liquidity)
    for level in liquidity_levels.get('equal_lows', []):
        distance = current_price - level['price']
        distance_atr = distance / atr
        
        if 0 < distance_atr < 5:
            approaching.append({
                'type': 'EQUAL_LOW',
                'price': level['price'],
                'touches': level.get('touches', 2),
                'distance': distance,
                'distance_atr': distance_atr,
                'strength': 'MAJOR',
                'direction_after_sweep': 'LONG',
                'proximity': 'IMMINENT' if distance_atr < 1 else 'CLOSE' if distance_atr < 2 else 'APPROACHING',
                'status': 'UNSWEPT',
                'formed_ago': 'multiple touches'
            })
    
    for level in liquidity_levels.get('equal_highs', []):
        distance = level['price'] - current_price
        distance_atr = distance / atr
        
        if 0 < distance_atr < 5:
            approaching.append({
                'type': 'EQUAL_HIGH',
                'price': level['price'],
                'touches': level.get('touches', 2),
                'distance': distance,
                'distance_atr': distance_atr,
                'strength': 'MAJOR',
                'direction_after_sweep': 'SHORT',
                'proximity': 'IMMINENT' if distance_atr < 1 else 'CLOSE' if distance_atr < 2 else 'APPROACHING',
                'status': 'UNSWEPT',
                'formed_ago': 'multiple touches'
            })
    
    # Sort by proximity
    approaching.sort(key=lambda x: x['distance_atr'])
    
    # Separate by direction for clearer display
    long_targets = [l for l in approaching if l['direction_after_sweep'] == 'LONG']
    short_targets = [l for l in approaching if l['direction_after_sweep'] == 'SHORT']
    
    # DEBUG: Show next targets with age
    if long_targets:
        lt = long_targets[0]
        print(f"[NEXT_TARGET] LONG: ${lt['price']:,.2f} ({lt['proximity']}, formed {lt.get('formed_ago', '?')})")
    if short_targets:
        st = short_targets[0]
        print(f"[NEXT_TARGET] SHORT: ${st['price']:,.2f} ({st['proximity']}, formed {st.get('formed_ago', '?')})")
    
    return {
        'has_nearby': len(approaching) > 0,
        'levels': approaching[:5],
        'imminent': [l for l in approaching if l['proximity'] == 'IMMINENT'],
        'next_long_target': long_targets[0] if long_targets else None,
        'next_short_target': short_targets[0] if short_targets else None
    }


# ═══════════════════════════════════════════════════════════════════════════════
# LIQUIDATION DATA (FREE SOURCES)
# ═══════════════════════════════════════════════════════════════════════════════

def get_binance_liquidations(symbol: str, period: str = '4h') -> Dict:
    """
    Get liquidation-related data from Binance (FREE).
    
    APIs used:
    - topLongShortPositionRatio: Top traders by POSITION SIZE (true whale activity)
    - globalLongShortAccountRatio: All accounts by count (retail sentiment)
    - fundingRate: Funding rate
    - openInterest: Open interest
    
    Args:
        symbol: Trading pair (e.g., 'BTCUSDT')
        period: Data period - '5m', '15m', '30m', '1h', '4h', '1d'
    """
    try:
        base_url = "https://fapi.binance.com"
        
        # Get funding rate
        funding_resp = requests.get(f"{base_url}/fapi/v1/fundingRate", 
                                     params={'symbol': symbol, 'limit': 1}, timeout=5)
        funding_data = funding_resp.json()
        funding_rate = float(funding_data[0]['fundingRate']) if funding_data else 0
        
        # Get open interest
        oi_resp = requests.get(f"{base_url}/fapi/v1/openInterest",
                               params={'symbol': symbol}, timeout=5)
        oi_data = oi_resp.json()
        open_interest = float(oi_data.get('openInterest', 0))
        
        # Get RETAIL long/short ratio (by account count)
        ls_resp = requests.get(f"{base_url}/futures/data/globalLongShortAccountRatio",
                               params={'symbol': symbol, 'period': period, 'limit': 1}, timeout=5)
        ls_data = ls_resp.json()
        if ls_data:
            retail_long = float(ls_data[0].get('longAccount', 0.5)) * 100
            retail_short = float(ls_data[0].get('shortAccount', 0.5)) * 100
        else:
            retail_long = 50
            retail_short = 50
        
        # Get WHALE long/short ratio (by POSITION SIZE - the correct metric!)
        # topLongShortPositionRatio measures by $$ position size, not account count
        whale_resp = requests.get(f"{base_url}/futures/data/topLongShortPositionRatio",
                                params={'symbol': symbol, 'period': period, 'limit': 1}, timeout=5)
        whale_data = whale_resp.json()
        if whale_data:
            whale_long = float(whale_data[0].get('longAccount', 0.5)) * 100
            whale_short = float(whale_data[0].get('shortAccount', 0.5)) * 100
        else:
            whale_long = 50
            whale_short = 50
        
        # Infer crowding
        crowded_long = retail_long > 60 and funding_rate > 0.0005
        crowded_short = retail_short > 60 and funding_rate < -0.0005
        
        return {
            'funding_rate': funding_rate,
            'funding_pct': funding_rate * 100,
            'open_interest': open_interest,
            'retail_long': retail_long,
            'retail_short': retail_short,
            'whale_long': whale_long,
            'whale_short': whale_short,
            'crowded_long': crowded_long,
            'crowded_short': crowded_short,
            'liquidation_bias': 'LONGS_AT_RISK' if crowded_long else 'SHORTS_AT_RISK' if crowded_short else 'NEUTRAL',
            'period': period,
            'success': True
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'funding_rate': 0,
            'retail_long': 50,
            'retail_short': 50,
            'whale_long': 50,
            'whale_short': 50
        }


def estimate_liquidation_zones(current_price: float, atr: float, 
                                 liquidation_data: Dict) -> Dict:
    """
    Estimate where liquidations likely cluster based on:
    - Typical leverage (10x-25x for crypto)
    - ATR for volatility context
    - Crowding data
    """
    # Common leverage levels and their liquidation distances
    leverage_levels = [
        {'leverage': 100, 'distance_pct': 1.0},   # 100x = 1% move
        {'leverage': 50, 'distance_pct': 2.0},    # 50x = 2% move
        {'leverage': 25, 'distance_pct': 4.0},    # 25x = 4% move
        {'leverage': 20, 'distance_pct': 5.0},    # 20x = 5% move
        {'leverage': 10, 'distance_pct': 10.0},   # 10x = 10% move
    ]
    
    long_liquidations = []  # Below current price
    short_liquidations = []  # Above current price
    
    for lev in leverage_levels:
        # Long liquidations (below price)
        liq_price_long = current_price * (1 - lev['distance_pct'] / 100)
        long_liquidations.append({
            'price': liq_price_long,
            'leverage': lev['leverage'],
            'distance_pct': lev['distance_pct'],
            'intensity': 'HIGH' if lev['leverage'] >= 25 else 'MEDIUM' if lev['leverage'] >= 15 else 'LOW'
        })
        
        # Short liquidations (above price)
        liq_price_short = current_price * (1 + lev['distance_pct'] / 100)
        short_liquidations.append({
            'price': liq_price_short,
            'leverage': lev['leverage'],
            'distance_pct': lev['distance_pct'],
            'intensity': 'HIGH' if lev['leverage'] >= 25 else 'MEDIUM' if lev['leverage'] >= 15 else 'LOW'
        })
    
    # Adjust intensity based on crowding
    if liquidation_data.get('crowded_long'):
        for liq in long_liquidations:
            liq['risk'] = 'ELEVATED'
    
    if liquidation_data.get('crowded_short'):
        for liq in short_liquidations:
            liq['opportunity'] = 'TP_TARGET'
    
    return {
        'long_liquidations': long_liquidations,
        'short_liquidations': short_liquidations,
        'bias': liquidation_data.get('liquidation_bias', 'NEUTRAL')
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TRADE PLAN GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

def generate_liquidity_trade_plan(symbol: str, current_price: float, atr: float,
                                   liquidity_levels: Dict, sweep_status: Dict,
                                   liquidation_data: Dict, whale_pct: float,
                                   df: pd.DataFrame = None) -> Dict:
    """
    Generate a complete trade plan based on liquidity analysis.
    
    Args:
        df: DataFrame with OHLC data to check if TPs were already hit
    """
    plan = {
        'symbol': symbol,
        'current_price': current_price,
        'status': 'NO_SETUP',
        'direction': None,
        'entry': None,
        'stop_loss': None,
        'take_profits': [],
        'risk_reward': None,
        'reasoning': [],
        'confidence': 0
    }
    
    # Get liquidation zones for TP targets
    liq_zones = estimate_liquidation_zones(current_price, atr, liquidation_data)
    
    # Helper to check if TP was already hit since sweep
    def check_tp_hit(tp_price: float, direction: str, candles_ago: int) -> dict:
        """Check if TP was already touched since sweep"""
        result = {'hit': False, 'hit_candle': None, 'high_since': None, 'low_since': None}
        
        if df is None or len(df) < 2 or candles_ago <= 0:
            print(f"[TP_HIT_DEBUG] Cannot check - df={df is not None}, len={len(df) if df is not None else 0}, candles_ago={candles_ago}")
            return result
        
        # Get candles since sweep
        candles_since = df.iloc[-candles_ago:] if candles_ago <= len(df) else df
        
        print(f"[TP_HIT_DEBUG] Checking TP ${tp_price:.2f} ({direction}), candles_ago={candles_ago}, checking {len(candles_since)} candles")
        
        if direction == 'LONG':
            # For LONG, check if HIGH went above TP
            high_since = candles_since['high'].max()
            result['high_since'] = high_since
            print(f"[TP_HIT_DEBUG] HIGH since sweep: ${high_since:.2f}, TP: ${tp_price:.2f}, HIT: {high_since >= tp_price}")
            if high_since >= tp_price:
                result['hit'] = True
                # Find which candle hit it
                for i, (idx, row) in enumerate(candles_since.iterrows()):
                    if row['high'] >= tp_price:
                        result['hit_candle'] = candles_ago - i
                        break
        else:  # SHORT
            # For SHORT, check if LOW went below TP
            low_since = candles_since['low'].min()
            result['low_since'] = low_since
            print(f"[TP_HIT_DEBUG] LOW since sweep: ${low_since:.2f}, TP: ${tp_price:.2f}, HIT: {low_since <= tp_price}")
            if low_since <= tp_price:
                result['hit'] = True
                for i, (idx, row) in enumerate(candles_since.iterrows()):
                    if row['low'] <= tp_price:
                        result['hit_candle'] = candles_ago - i
                        break
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════
    # SCENARIO 1: SWEEP DETECTED - IMMEDIATE ENTRY
    # ═══════════════════════════════════════════════════════════════════════
    if sweep_status.get('detected'):
        direction = sweep_status['direction']
        
        if direction == 'LONG':
            entry = current_price  # Enter now on sweep confirmation
            sweep_low = sweep_status.get('sweep_low') or sweep_status.get('level_swept', current_price)
            sweep_candles = sweep_status.get('candles_ago', 0)
            
            # Find the NEXT liquidity level below current price (excluding already swept)
            lows_for_sl = [l for l in liquidity_levels.get('lows', []) 
                          if l.get('price', 0) < current_price and not l.get('swept', False)]
            lows_for_sl = sorted(lows_for_sl, key=lambda x: x.get('price', 0), reverse=True)  # Highest first
            
            if lows_for_sl:
                # Put SL below the nearest unswept liquidity level
                nearest_low = lows_for_sl[0].get('price', sweep_low)
                stop_loss = nearest_low - (atr * 0.3)
                print(f"[TRADE_PLAN] SL below nearest liquidity: ${nearest_low:.2f} → SL=${stop_loss:.2f}")
            else:
                # No fresh lows - use sweep level or tight stop
                if sweep_candles > 10:
                    # OLD sweep - use tighter stop
                    stop_loss = current_price * 0.985 - (atr * 0.2)
                    print(f"[TRADE_PLAN] No fresh lows, OLD sweep - tight SL: ${stop_loss:.2f}")
                else:
                    # Fresh sweep - stop below sweep level
                    stop_loss = sweep_low - (atr * 0.3)
                    print(f"[TRADE_PLAN] No fresh lows, FRESH sweep - SL below sweep: ${stop_loss:.2f}")
            
            # TPs at ACTUAL liquidity levels above (highs) - SAME as Sequence Map!
            # IMPORTANT: Only use UNSWEPT levels!
            # COMBINE liquidity levels AND liquidation zones, then sort by DISTANCE
            tps = []
            
            # Get highs above current price (liquidity pools)
            highs_above = [h for h in liquidity_levels.get('highs', []) 
                         if h.get('price', 0) > current_price and not h.get('swept', False)]
            
            # Add liquidation zones as potential TPs too!
            for liq in liq_zones.get('short_liquidations', []):
                liq_price = liq.get('price', 0)
                if liq_price > current_price:
                    # Check if not already covered by chart levels (within 0.5%)
                    if not any(abs(h.get('price', 0) - liq_price) / liq_price < 0.005 for h in highs_above):
                        highs_above.append({
                            'price': liq_price,
                            'type': f"Short Liq ({liq.get('leverage', '?')}x)",
                            'strength': 'MODERATE'
                        })
            
            # SORT BY DISTANCE (closest first) - this is the key fix!
            highs_above = sorted(highs_above, key=lambda x: x.get('price', 0))
            
            print(f"[TRADE_PLAN_DEBUG] LONG TPs: entry=${entry:.2f}, stop=${stop_loss:.2f}, risk=${entry-stop_loss:.2f}")
            print(f"[TRADE_PLAN_DEBUG] All targets above (sorted by distance): {len(highs_above)}")
            for h in highs_above[:5]:
                tp_price = h.get('price', 0)
                if entry > stop_loss:
                    rr = (tp_price - entry) / (entry - stop_loss) if tp_price > entry else 0
                    print(f"[TRADE_PLAN_DEBUG]   ${tp_price:.2f} ({h.get('type', 'unknown')}) → R:R={rr:.2f}")
            
            for i, level in enumerate(highs_above[:3]):
                price = level.get('price', 0)
                level_type = level.get('type', 'Liquidity Pool')
                if entry > stop_loss and price > entry:
                    rr = (price - entry) / (entry - stop_loss)
                    roi = ((price - entry) / entry) * 100
                    
                    # Check if this TP was already hit since sweep
                    sweep_candles = sweep_status.get('candles_ago', 0)
                    tp_hit_info = check_tp_hit(price, 'LONG', sweep_candles)
                    
                    # Include ALL TPs but mark status
                    if rr >= 0.3:
                        tp_entry = {
                            'level': i + 1,
                            'price': price,
                            'reason': level_type,
                            'rr': rr,
                            'roi': roi,
                            'low_rr': rr < 1.0,
                            'hit': tp_hit_info['hit'],
                            'hit_candle': tp_hit_info.get('hit_candle')
                        }
                        
                        # Update reason with status
                        if tp_hit_info['hit']:
                            tp_entry['reason'] = f"{level_type} ✅ HIT ({tp_hit_info['hit_candle']}c ago)"
                        elif rr < 1.0:
                            tp_entry['reason'] = f"{level_type} (⚠️ R:R {rr:.1f})"
                            
                        tps.append(tp_entry)
            
            plan.update({
                'status': 'SWEEP_ENTRY',
                'direction': 'LONG',
                'entry': entry,
                'stop_loss': stop_loss,
                'take_profits': tps,
                'risk_reward': tps[0]['rr'] if tps else 0,
                'confidence': sweep_status.get('confidence', 60),
                'reasoning': [
                    f"✅ Liquidity sweep detected at ${sweep_status.get('level_swept', 0):.2f}",
                    f"✅ Price rejected back above level",
                    f"{'✅' if sweep_status.get('volume_confirmed') else '⚠️'} Volume {'confirmed' if sweep_status.get('volume_confirmed') else 'not confirmed'}",
                    f"🎯 Targeting FRESH liquidity levels above"
                ]
            })
            
            # Boost confidence if whale aligned
            if whale_pct > 55:
                plan['confidence'] = min(95, plan['confidence'] + 15)
                plan['reasoning'].append(f"✅ Whales {whale_pct:.0f}% LONG - aligned with sweep direction")
        
        elif direction == 'SHORT':
            entry = current_price
            sweep_high = sweep_status.get('sweep_high') or sweep_status.get('level_swept', current_price)
            sweep_candles = sweep_status.get('candles_ago', 0)
            
            # Find the NEXT liquidity level above current price (excluding already swept)
            highs_for_sl = [h for h in liquidity_levels.get('highs', []) 
                           if h.get('price', 0) > current_price and not h.get('swept', False)]
            highs_for_sl = sorted(highs_for_sl, key=lambda x: x.get('price', 0))  # Lowest first
            
            if highs_for_sl:
                # Put SL above the nearest unswept liquidity level
                nearest_high = highs_for_sl[0].get('price', sweep_high)
                stop_loss = nearest_high + (atr * 0.3)
                print(f"[TRADE_PLAN] SL above nearest liquidity: ${nearest_high:.2f} → SL=${stop_loss:.2f}")
            else:
                # No fresh highs - use sweep level or tight stop
                if sweep_candles > 10:
                    stop_loss = current_price * 1.015 + (atr * 0.2)
                    print(f"[TRADE_PLAN] No fresh highs, OLD sweep - tight SL: ${stop_loss:.2f}")
                else:
                    stop_loss = sweep_high + (atr * 0.3)
                    print(f"[TRADE_PLAN] No fresh highs, FRESH sweep - SL above sweep: ${stop_loss:.2f}")
            
            # TPs at ACTUAL liquidity levels below (lows) - SAME as Sequence Map!
            # COMBINE liquidity levels AND liquidation zones, then sort by DISTANCE
            tps = []
            
            # Get lows below current price (liquidity pools)
            lows_below = [l for l in liquidity_levels.get('lows', []) 
                         if l.get('price', 0) < current_price and not l.get('swept', False)]
            
            # Add liquidation zones as potential TPs too!
            for liq in liq_zones.get('long_liquidations', []):
                liq_price = liq.get('price', 0)
                if liq_price < current_price:
                    # Check if not already covered by chart levels (within 0.5%)
                    if not any(abs(l.get('price', 0) - liq_price) / liq_price < 0.005 for l in lows_below):
                        lows_below.append({
                            'price': liq_price,
                            'type': f"Long Liq ({liq.get('leverage', '?')}x)",
                            'strength': 'MODERATE'
                        })
            
            # SORT BY DISTANCE (closest first = highest price for SHORT TPs)
            lows_below = sorted(lows_below, key=lambda x: x.get('price', 0), reverse=True)
            
            for i, level in enumerate(lows_below[:3]):
                price = level.get('price', 0)
                level_type = level.get('type', 'Liquidity Pool')
                if stop_loss > entry and price < entry:
                    rr = (entry - price) / (stop_loss - entry)
                    roi = ((entry - price) / entry) * 100
                    
                    # Check if this TP was already hit since sweep
                    sweep_candles = sweep_status.get('candles_ago', 0)
                    tp_hit_info = check_tp_hit(price, 'SHORT', sweep_candles)
                    
                    # Include ALL TPs but mark status
                    if rr >= 0.3:
                        tp_entry = {
                            'level': i + 1,
                            'price': price,
                            'reason': level_type,
                            'rr': rr,
                            'roi': roi,
                            'low_rr': rr < 1.0,
                            'hit': tp_hit_info['hit'],
                            'hit_candle': tp_hit_info.get('hit_candle')
                        }
                        
                        # Update reason with status
                        if tp_hit_info['hit']:
                            tp_entry['reason'] = f"{level_type} ✅ HIT ({tp_hit_info['hit_candle']}c ago)"
                        elif rr < 1.0:
                            tp_entry['reason'] = f"{level_type} (⚠️ R:R {rr:.1f})"
                            
                        tps.append(tp_entry)
            
            plan.update({
                'status': 'SWEEP_ENTRY',
                'direction': 'SHORT',
                'entry': entry,
                'stop_loss': stop_loss,
                'take_profits': tps,
                'risk_reward': tps[0]['rr'] if tps else 0,
                'confidence': sweep_status.get('confidence', 60),
                'reasoning': [
                    f"✅ Liquidity sweep detected at ${sweep_status.get('level_swept', 0):.2f}",
                    f"✅ Price rejected back below level",
                    f"🎯 Targeting FRESH liquidity levels below"
                ]
            })
            
            if whale_pct < 45:
                plan['confidence'] = min(95, plan['confidence'] + 15)
                plan['reasoning'].append(f"✅ Whales {whale_pct:.0f}% SHORT - aligned")
        
        return plan
    
    # ═══════════════════════════════════════════════════════════════════════
    # SCENARIO 2: APPROACHING LIQUIDITY - WAIT FOR SWEEP
    # ═══════════════════════════════════════════════════════════════════════
    approaching = check_approaching_liquidity(current_price, liquidity_levels, atr)
    
    if approaching['has_nearby']:
        nearest = approaching['levels'][0]
        
        if nearest['type'] in ['LOW', 'EQUAL_LOW']:
            # Price approaching lows - wait for sweep then LONG
            # Estimate entry at sweep level, SL below
            est_entry = nearest['price']
            est_sl = nearest['price'] - (atr * 0.5)
            est_sl_pct = ((est_entry - est_sl) / est_entry) * 100
            
            # Estimate TPs from liquidation zones above
            est_tps = []
            for i, liq in enumerate(liq_zones.get('short_liquidations', [])[:3]):
                if liq['price'] > est_entry:
                    tp_roi = ((liq['price'] - est_entry) / est_entry) * 100
                    rr = (liq['price'] - est_entry) / (est_entry - est_sl)
                    est_tps.append({
                        'level': i + 1,
                        'price': liq['price'],
                        'reason': f"Short Liq ({liq['leverage']}x)",
                        'roi': tp_roi,
                        'rr': rr
                    })
            
            plan.update({
                'status': 'WAITING_FOR_SWEEP',
                'direction': 'LONG (after sweep)',
                'sweep_level': nearest['price'],
                'est_entry': est_entry,
                'est_sl': est_sl,
                'est_sl_pct': est_sl_pct,
                'est_tps': est_tps,
                'proximity': nearest['proximity'],
                'confidence': 40 if nearest['proximity'] == 'APPROACHING' else 60 if nearest['proximity'] == 'CLOSE' else 75,
                'reasoning': [
                    f"🔍 Price approaching liquidity at {nearest['price']:.2f}",
                    f"📏 Distance: {nearest['distance_atr']:.1f} ATR ({nearest['proximity']})",
                    f"📊 Level strength: {nearest['strength']}",
                    f"⏳ WAIT for sweep + rejection before entering LONG"
                ]
            })
            
            if nearest['type'] == 'EQUAL_LOW':
                plan['reasoning'].insert(1, f"⭐ EQUAL LOW with {nearest.get('touches', 2)} touches - HIGH probability")
                plan['confidence'] += 10
        
        elif nearest['type'] in ['HIGH', 'EQUAL_HIGH']:
            # Price approaching highs - wait for sweep then SHORT
            est_entry = nearest['price']
            est_sl = nearest['price'] + (atr * 0.5)
            est_sl_pct = ((est_sl - est_entry) / est_entry) * 100
            
            # Estimate TPs from liquidation zones below
            est_tps = []
            for i, liq in enumerate(liq_zones.get('long_liquidations', [])[:3]):
                if liq['price'] < est_entry:
                    tp_roi = ((est_entry - liq['price']) / est_entry) * 100
                    rr = (est_entry - liq['price']) / (est_sl - est_entry)
                    est_tps.append({
                        'level': i + 1,
                        'price': liq['price'],
                        'reason': f"Long Liq ({liq['leverage']}x)",
                        'roi': tp_roi,
                        'rr': rr
                    })
            
            plan.update({
                'status': 'WAITING_FOR_SWEEP',
                'direction': 'SHORT (after sweep)',
                'sweep_level': nearest['price'],
                'est_entry': est_entry,
                'est_sl': est_sl,
                'est_sl_pct': est_sl_pct,
                'est_tps': est_tps,
                'proximity': nearest['proximity'],
                'confidence': 40 if nearest['proximity'] == 'APPROACHING' else 60 if nearest['proximity'] == 'CLOSE' else 75,
                'reasoning': [
                    f"🔍 Price approaching liquidity at {nearest['price']:.2f}",
                    f"📏 Distance: {nearest['distance_atr']:.1f} ATR ({nearest['proximity']})",
                    f"⏳ WAIT for sweep + rejection before entering SHORT"
                ]
            })
            
            if nearest['type'] == 'EQUAL_HIGH':
                plan['reasoning'].insert(1, f"⭐ EQUAL HIGH with {nearest.get('touches', 2)} touches - HIGH probability")
                plan['confidence'] += 10
        
        return plan
    
    # ═══════════════════════════════════════════════════════════════════════
    # SCENARIO 3: NO IMMEDIATE SETUP
    # ═══════════════════════════════════════════════════════════════════════
    # Find nearest levels for monitoring
    all_levels = []
    for l in liquidity_levels.get('lows', []):
        all_levels.append({'price': l['price'], 'type': 'LOW', 'strength': l.get('strength')})
    for h in liquidity_levels.get('highs', []):
        all_levels.append({'price': h['price'], 'type': 'HIGH', 'strength': h.get('strength')})
    
    all_levels.sort(key=lambda x: abs(x['price'] - current_price))
    
    plan.update({
        'status': 'NO_SETUP',
        'direction': None,
        'watch_levels': all_levels[:5],
        'reasoning': [
            "⏳ No liquidity sweep detected",
            "⏳ Price not near key liquidity levels",
            f"👀 Monitoring {len(all_levels)} liquidity levels",
            "💡 Best setups come AFTER sweeps, not before"
        ],
        'confidence': 0
    })
    
    return plan


# ═══════════════════════════════════════════════════════════════════════════════
# SCANNER FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

def scan_for_liquidity_setups(symbols: List[str], fetch_data_func, 
                               timeframe: str = '4h', trading_mode: str = 'swing',
                               max_symbols: int = 20, progress_callback=None) -> List[Dict]:
    """
    Scan multiple symbols for liquidity sweep setups.
    
    Args:
        symbols: List of symbols to scan
        fetch_data_func: Function to fetch candle data
        timeframe: Candle timeframe
        trading_mode: 'scalp', 'day_trade', 'swing', or 'investment'
        max_symbols: Maximum number of symbols to scan (10, 20, 50, 100)
        progress_callback: Optional callback(current, total) for progress updates
    
    Returns list of symbols with:
    - Active sweeps (ENTRY NOW)
    - Approaching liquidity (WATCH)
    """
    # Map trading mode to lookback candles
    lookback_map = {
        'scalp': 10,
        'day_trade': 25,
        'swing': 40,
        'investment': 50
    }
    lookback_candles = lookback_map.get(trading_mode.lower().replace(' ', '_'), 25)
    
    results = []
    
    # Limit symbols to scan
    symbols_to_scan = symbols[:max_symbols]
    total = len(symbols_to_scan)
    
    for idx, symbol in enumerate(symbols_to_scan):
        # Progress callback
        if progress_callback:
            progress_callback(idx + 1, total)
        
        try:
            # Fetch candle data
            df = fetch_data_func(symbol, timeframe)
            if df is None or len(df) < 50:
                continue
            
            # Normalize column names
            df = normalize_columns(df)
            
            # Calculate ATR
            high = df['high']
            low = df['low']
            close = df['close']
            tr = pd.concat([high - low, abs(high - close.shift()), abs(low - close.shift())], axis=1).max(axis=1)
            atr = tr.rolling(14).mean().iloc[-1]
            
            current_price = close.iloc[-1]
            
            # Get whale data first (needed for sweep detection)
            is_crypto = 'USDT' in symbol or 'USD' in symbol
            if is_crypto:
                whale_data = get_binance_liquidations(symbol)
                whale_pct = whale_data.get('whale_long', 50)
            else:
                whale_pct = 50
                whale_data = {}
            
            # Find liquidity levels
            liquidity_levels = find_liquidity_levels(df)
            
            # Check for sweep (with whale alignment)
            sweep_status = detect_sweep(df, liquidity_levels, atr, lookback_candles, whale_pct)
            
            # Check approaching
            approaching = check_approaching_liquidity(current_price, liquidity_levels, atr)
            
            # Determine status
            if sweep_status.get('detected'):
                status = 'SWEEP_ACTIVE'
                priority = 1
            elif approaching.get('imminent'):
                status = 'IMMINENT'
                priority = 2
            elif approaching.get('has_nearby'):
                status = 'APPROACHING'
                priority = 3
            else:
                status = 'MONITORING'
                priority = 4
            
            results.append({
                'symbol': symbol,
                'current_price': float(current_price),
                'status': status,
                'priority': priority,
                'sweep': sweep_status if sweep_status.get('detected') else None,
                'approaching': approaching['levels'][0] if approaching.get('has_nearby') else None,
                'whale_pct': whale_pct,
                'liquidity_levels_count': len(liquidity_levels.get('lows', [])) + len(liquidity_levels.get('highs', [])),
                'has_equal_levels': len(liquidity_levels.get('equal_lows', [])) + len(liquidity_levels.get('equal_highs', [])) > 0
            })
            
        except Exception as e:
            print(f"Error scanning {symbol}: {e}")
            continue
    
    # Sort by priority (sweeps first, then approaching, then monitoring)
    results.sort(key=lambda x: (x['priority'], -x.get('whale_pct', 50)))
    
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# FULL ANALYSIS FOR SINGLE SYMBOL
# ═══════════════════════════════════════════════════════════════════════════════

def full_liquidity_analysis(symbol: str, df: pd.DataFrame, whale_pct: float = 50, trading_mode: str = 'day_trade') -> Dict:
    """
    Complete liquidity analysis for a single symbol.
    
    Args:
        trading_mode: 'scalp', 'day_trade', 'swing', or 'investment'
    """
    if df is None or len(df) < 50:
        return {'error': 'Insufficient data'}
    
    # Normalize column names
    df = normalize_columns(df)
    
    # Map trading mode to lookback candles
    lookback_map = {
        'scalp': 10,        # ~50 min on 5m (fresh sweeps only)
        'day_trade': 25,    # ~6 hrs on 15m
        'swing': 40,        # ~1 week on 4h
        'investment': 50    # ~50 days on 1d
    }
    lookback_candles = lookback_map.get(trading_mode.lower().replace(' ', '_'), 25)
    
    # Calculate ATR
    high = df['high']
    low = df['low']
    close = df['close']
    tr = pd.concat([high - low, abs(high - close.shift()), abs(low - close.shift())], axis=1).max(axis=1)
    atr = float(tr.rolling(14).mean().iloc[-1])
    
    current_price = float(close.iloc[-1])
    
    # Get all analysis components
    liquidity_levels = find_liquidity_levels(df)
    
    # DEBUG: Show what levels exist
    lows_prices = [(round(l.get('price', 0), 2), len(df) - l.get('index', 0)) for l in liquidity_levels.get('lows', [])[:5]]
    swept_lows_prices = [(round(l.get('price', 0), 2), l.get('swept_candles_ago', '?')) for l in liquidity_levels.get('recently_swept_lows', [])[:5]]
    print(f"[LEVELS_DEBUG] UNSWEPT lows (fresh targets): {lows_prices}  ← (price, candles_since_formed)")
    print(f"[LEVELS_DEBUG] SWEPT lows (already used): {swept_lows_prices}  ← (price, candles_since_sweep)")
    
    sweep_status = detect_sweep(df, liquidity_levels, atr, lookback_candles, whale_pct)
    approaching = check_approaching_liquidity(current_price, liquidity_levels, atr)
    
    # Get liquidation data for crypto
    is_crypto = 'USDT' in symbol.upper()
    if is_crypto:
        liquidation_data = get_binance_liquidations(symbol)
    else:
        liquidation_data = {'success': False, 'retail_long': 50, 'retail_short': 50, 'whale_long': 50, 'whale_short': 50}
    
    # ML Prediction for sweep quality
    ml_prediction = None
    if sweep_status.get('detected') and LH_ML_AVAILABLE:
        try:
            whale_data = {
                'whale_long': liquidation_data.get('whale_long', whale_pct),
                'retail_long': liquidation_data.get('retail_long', 50)
            }
            market_data = {
                'atr': atr,
                'htf_trend': None,  # Can add HTF context
                'btc_correlation': 0,
                'fear_greed': 50
            }
            ml_prediction = predict_sweep_quality(sweep_status, whale_data, market_data)
            print(f"[LH_ML] Prediction: {ml_prediction.get('prediction')} ({ml_prediction.get('probability', 0):.1%})")
        except Exception as e:
            print(f"[LH_ML] Prediction error: {e}")
            ml_prediction = None
    
    # Generate trade plan
    trade_plan = generate_liquidity_trade_plan(
        symbol, current_price, atr,
        liquidity_levels, sweep_status,
        liquidation_data, whale_pct,
        df=df  # Pass df for TP hit detection
    )
    
    # Add ML prediction to trade plan if available
    if ml_prediction:
        trade_plan['ml_prediction'] = ml_prediction
        trade_plan['ml_quality'] = ml_prediction.get('prediction', 'UNKNOWN')
        trade_plan['ml_probability'] = ml_prediction.get('probability', 0)
    
    # Get liquidation zones
    liq_zones = estimate_liquidation_zones(current_price, atr, liquidation_data)
    
    # ═══════════════════════════════════════════════════════════════════════
    # AUTO-SAVE LIQUIDATION DATA FOR ML TRAINING
    # Every scan = new data point for future training on REAL levels!
    # ═══════════════════════════════════════════════════════════════════════
    try:
        from liquidity_hunter.liq_level_collector import save_liquidation_snapshot
        
        # Extract levels from liq_zones
        levels_to_save = {}
        for liq in liq_zones.get('long_liquidations', []):
            lev = liq.get('leverage', 0)
            price = liq.get('price', 0)
            if lev == 100:
                levels_to_save['100x_below'] = price
            elif lev == 50:
                levels_to_save['50x_below'] = price
            elif lev == 25:
                levels_to_save['25x_below'] = price
        
        for liq in liq_zones.get('short_liquidations', []):
            lev = liq.get('leverage', 0)
            price = liq.get('price', 0)
            if lev == 100:
                levels_to_save['100x_above'] = price
            elif lev == 50:
                levels_to_save['50x_above'] = price
            elif lev == 25:
                levels_to_save['25x_above'] = price
        
        # Get whale delta if available
        whale_delta = liquidation_data.get('whale_delta', 0)
        
        # Save snapshot (non-blocking)
        if levels_to_save:
            save_liquidation_snapshot(
                symbol=symbol,
                price=current_price,
                levels=levels_to_save,
                whale_pct=whale_pct,
                whale_delta=whale_delta,
                atr=atr,
                data_source='scanner'
            )
    except Exception as e:
        pass  # Don't break analysis if collector fails
    
    return {
        'symbol': symbol,
        'current_price': current_price,
        'atr': atr,
        'liquidity_levels': liquidity_levels,
        'sweep_status': sweep_status,
        'approaching': approaching,
        'liquidation_data': liquidation_data,
        'liquidation_zones': liq_zones,
        'trade_plan': trade_plan,
        'ml_prediction': ml_prediction,
        'is_crypto': is_crypto
    }