"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                      LIQUIDITY HUNTER UI COMPONENTS                            ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import streamlit as st


def render_liquidity_sequence(analysis: dict):
    """
    Render a clear liquidity sequence diagram showing:
    - SWEPT levels (already taken - greyed out)
    - FRESH levels (available targets)
    - Current price position
    - Next targets with clear arrows
    
    This helps traders understand WHERE they are in the liquidity cycle.
    """
    current_price = analysis.get('current_price', 0)
    sweep = analysis.get('sweep', {})
    approaching = analysis.get('approaching', [])
    liquidity_levels = analysis.get('liquidity_levels', {})
    
    # Determine if we have an active sweep
    sweep_active = sweep.get('is_sweep', False)
    sweep_level = sweep.get('level_swept', 0)
    sweep_direction = sweep.get('direction', '')
    candles_since = sweep.get('candles_since', 0)
    
    # Build list of all levels with status
    levels_above = []  # SHORT territory
    levels_below = []  # LONG territory
    
    # Add highs (SHORT sweep targets)
    for h in liquidity_levels.get('highs', []):
        if h['price'] > current_price:
            levels_above.append({
                'price': h['price'],
                'type': 'LIQUIDITY_POOL',
                'strength': h.get('strength', 'MODERATE'),
                'swept': False,
                'is_target': True,
                'direction': 'SHORT'
            })
    
    # Add equal highs
    for eh in liquidity_levels.get('equal_highs', []):
        if eh['price'] > current_price:
            levels_above.append({
                'price': eh['price'],
                'type': 'EQUAL_HIGH',
                'strength': 'MAJOR',
                'swept': False,
                'is_target': True,
                'direction': 'SHORT'
            })
    
    # Add lows (LONG sweep targets)
    for l in liquidity_levels.get('lows', []):
        if l['price'] < current_price:
            # Check if this level was swept
            was_swept = False
            if sweep_active and sweep_direction == 'LONG':
                if abs(l['price'] - sweep_level) / sweep_level < 0.005:  # Within 0.5%
                    was_swept = True
            
            levels_below.append({
                'price': l['price'],
                'type': 'LIQUIDITY_POOL',
                'strength': l.get('strength', 'MODERATE'),
                'swept': was_swept,
                'candles_since': candles_since if was_swept else 0,
                'is_target': not was_swept,
                'direction': 'LONG'
            })
    
    # Add equal lows
    for el in liquidity_levels.get('equal_lows', []):
        if el['price'] < current_price:
            was_swept = False
            if sweep_active and sweep_direction == 'LONG':
                if abs(el['price'] - sweep_level) / sweep_level < 0.005:
                    was_swept = True
            
            levels_below.append({
                'price': el['price'],
                'type': 'EQUAL_LOW',
                'strength': 'MAJOR',
                'swept': was_swept,
                'candles_since': candles_since if was_swept else 0,
                'is_target': not was_swept,
                'direction': 'LONG'
            })
    
    # Sort levels
    levels_above.sort(key=lambda x: x['price'])  # Ascending (closest first)
    levels_below.sort(key=lambda x: x['price'], reverse=True)  # Descending (closest first)
    
    # Find NEXT targets (first FRESH level in each direction)
    next_long_target = next((l for l in levels_below if not l['swept']), None)
    next_short_target = levels_above[0] if levels_above else None
    
    # Render the sequence
    st.markdown("#### 📍 Liquidity Sequence")
    
    # Current status
    if sweep_active:
        status_emoji = "✅" if candles_since <= 3 else "⏰"
        status_text = f"SWEEP ACTIVE at ${sweep_level:,.2f} ({candles_since} candles ago)"
        if candles_since <= 3:
            st.success(f"{status_emoji} **{status_text}** - Entry window OPEN!")
        elif candles_since <= 10:
            st.warning(f"{status_emoji} **{status_text}** - Entry window closing...")
        else:
            st.info(f"{status_emoji} **{status_text}** - Sweep is old, wait for retest or next sweep")
    
    # Create two columns for the visualization
    col_left, col_right = st.columns([2, 1])
    
    with col_left:
        # SHORT Territory (Above)
        st.markdown("**🔴 SHORT Territory** (Above Price)")
        
        if levels_above:
            for i, level in enumerate(levels_above[:4]):
                strength_emoji = "⭐" if level['strength'] == 'MAJOR' else "🔹" if level['strength'] == 'STRONG' else "▫️"
                is_next = (next_short_target and level['price'] == next_short_target['price'])
                
                if is_next:
                    st.markdown(f"**→ ${level['price']:,.2f}** {strength_emoji} {level['type']} ({level['strength']}) ← **NEXT SHORT TARGET**")
                else:
                    st.markdown(f"   ${level['price']:,.2f} {strength_emoji} {level['type']} ({level['strength']})")
        else:
            st.caption("No short liquidity pools detected above")
        
        st.markdown("---")
        
        # Current Price
        st.markdown(f"### 📍 **${current_price:,.2f}** ← YOU ARE HERE")
        
        st.markdown("---")
        
        # LONG Territory (Below)
        st.markdown("**🟢 LONG Territory** (Below Price)")
        
        if levels_below:
            for i, level in enumerate(levels_below[:4]):
                strength_emoji = "⭐" if level['strength'] == 'MAJOR' else "🔹" if level['strength'] == 'STRONG' else "▫️"
                is_next = (next_long_target and level['price'] == next_long_target['price'])
                
                if level['swept']:
                    st.markdown(f"   ~~${level['price']:,.2f}~~ ✅ **SWEPT** ({level.get('candles_since', 0)} candles ago) - Liquidity TAKEN")
                elif is_next:
                    st.markdown(f"**→ ${level['price']:,.2f}** {strength_emoji} {level['type']} ({level['strength']}) ← **NEXT LONG TARGET**")
                else:
                    st.markdown(f"   ${level['price']:,.2f} {strength_emoji} {level['type']} ({level['strength']})")
        else:
            st.caption("No long liquidity pools detected below")
    
    with col_right:
        # Sequence Flow Diagram
        st.markdown("**📊 Sequence Flow**")
        
        if sweep_active and sweep_direction == 'LONG':
            # Show the flow for a LONG sweep
            st.markdown("""
            ```
            ┌─────────────────┐
            │ 1. SWEEP DONE ✓ │
            │   (LONG entry)  │
            └────────┬────────┘
                     ▼
            ┌─────────────────┐
            │ 2. NOW: Hold    │
            │   or Trail SL   │
            └────────┬────────┘
                     ▼
            ┌─────────────────┐
            │ 3. NEXT: Short  │
            │   Liq = TP      │
            └─────────────────┘
            ```
            """)
        elif sweep_active and sweep_direction == 'SHORT':
            st.markdown("""
            ```
            ┌─────────────────┐
            │ 1. SWEEP DONE ✓ │
            │  (SHORT entry)  │
            └────────┬────────┘
                     ▼
            ┌─────────────────┐
            │ 2. NOW: Hold    │
            │   or Trail SL   │
            └────────┬────────┘
                     ▼
            ┌─────────────────┐
            │ 3. NEXT: Long   │
            │   Liq = TP      │
            └─────────────────┘
            ```
            """)
        else:
            st.markdown("""
            ```
            ┌─────────────────┐
            │ WAITING...      │
            │ No active sweep │
            └────────┬────────┘
                     ▼
            ┌─────────────────┐
            │ Watch for:      │
            │ • Price → Level │
            │ • Wick through  │
            │ • Close back    │
            └─────────────────┘
            ```
            """)
        
        # Next Actions
        st.markdown("**🎯 Next Actions:**")
        
        if sweep_active:
            if candles_since <= 3:
                st.success("✅ Entry window OPEN")
                st.caption("Market or limit entry valid")
            elif candles_since <= 10:
                st.warning("⏰ Consider limit at retest")
                st.caption(f"Retest level: ~${sweep_level:,.2f}")
            else:
                st.info("⏳ Sweep is old")
                st.caption("Wait for retest or next sweep")
            
            # Next TP target
            if sweep_direction == 'LONG' and next_short_target:
                st.markdown(f"**TP Target:** ${next_short_target['price']:,.2f}")
            elif sweep_direction == 'SHORT' and next_long_target:
                st.markdown(f"**TP Target:** ${next_long_target['price']:,.2f}")
        else:
            if next_long_target:
                st.markdown(f"**Next LONG sweep:** ${next_long_target['price']:,.2f}")
            if next_short_target:
                st.markdown(f"**Next SHORT sweep:** ${next_short_target['price']:,.2f}")


def render_next_targets_improved(analysis: dict):
    """
    Render improved Next Targets section that clearly distinguishes:
    - SWEPT levels (crossed out, with timing)
    - FRESH levels (highlighted as targets)
    """
    sweep = analysis.get('sweep', {})
    approaching = analysis.get('approaching', [])
    current_price = analysis.get('current_price', 0)
    
    sweep_active = sweep.get('is_sweep', False)
    sweep_level = sweep.get('level_swept', 0)
    candles_since = sweep.get('candles_since', 0)
    sweep_direction = sweep.get('direction', '')
    
    st.markdown("#### 🎯 Next Targets")
    
    # Show swept level first (if active)
    if sweep_active:
        freshness = "🟢 FRESH" if candles_since <= 3 else "🟡 AGING" if candles_since <= 10 else "⚪ OLD"
        
        col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
        with col1:
            st.markdown(f"~~${sweep_level:,.2f}~~ - {candles_since} candles ago")
        with col2:
            st.markdown(f"✅ **SWEPT**")
        with col3:
            st.markdown(freshness)
        with col4:
            st.markdown(f"→ {sweep_direction}")
    
    # Show approaching levels (FRESH)
    if approaching:
        for app in approaching[:3]:
            level_price = app.get('level', 0)
            distance = app.get('distance_atr', 0)
            direction = app.get('direction_after_sweep', 'LONG')
            
            # Skip if this is the swept level
            if sweep_active and abs(level_price - sweep_level) / sweep_level < 0.005:
                continue
            
            status = "🔥 IMMINENT" if distance < 0.5 else "⚡ APPROACHING" if distance < 1.0 else "👀 WATCHING"
            
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            with col1:
                st.markdown(f"**${level_price:,.2f}**")
            with col2:
                st.markdown(status)
            with col3:
                st.markdown(f"{distance:.1f} ATR")
            with col4:
                dir_emoji = "🟢" if direction == 'LONG' else "🔴"
                st.markdown(f"{dir_emoji} → {direction}")
    else:
        if not sweep_active:
            st.caption("No imminent targets. Monitoring liquidity levels...")


def render_liquidity_header():
    """Render the Liquidity Hunter header"""
    st.markdown("""
        <div style='background: linear-gradient(135deg, #1a1a2e 0%, #0a192f 100%); 
                    border-radius: 15px; padding: 20px; margin-bottom: 20px;
                    border: 2px solid #00d4aa;'>
            <div style='display: flex; align-items: center; gap: 15px;'>
                <div style='font-size: 2.5em;'>🎯</div>
                <div>
                    <div style='color: #00d4aa; font-size: 1.8em; font-weight: bold;'>
                        LIQUIDITY HUNTER
                    </div>
                    <div style='color: #888; font-size: 0.95em;'>
                        Follow the whale footprints • Enter at sweeps • Exit into liquidations
                    </div>
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)


def render_liquidity_map(analysis: dict):
    """Render the visual liquidity map"""
    current_price = analysis.get('current_price', 0)
    liquidity_levels = analysis.get('liquidity_levels', {})
    liq_zones = analysis.get('liquidation_zones', {})
    
    # Build levels for display
    all_levels = []
    
    # Add short liquidation zones (above price)
    for liq in liq_zones.get('short_liquidations', [])[:3]:
        all_levels.append({
            'price': liq['price'], 'type': 'SHORT_LIQ',
            'label': f"Short Liq ({liq['leverage']}x)", 'color': '#00ff88', 'arrow': '◄── TP TARGET'
        })
    
    # Add liquidity highs
    for h in liquidity_levels.get('highs', [])[:3]:
        if h['price'] > current_price:
            all_levels.append({
                'price': h['price'], 'type': 'LIQUIDITY_HIGH',
                'label': f"Liquidity Pool ({h.get('strength', 'MODERATE')})", 
                'color': '#ff6b6b', 'arrow': '◄── SWEEP FOR SHORT'
            })
    
    # Add equal highs
    for eh in liquidity_levels.get('equal_highs', []):
        if eh['price'] > current_price:
            all_levels.append({
                'price': eh['price'], 'type': 'EQUAL_HIGH',
                'label': f"Equal High ⭐", 'color': '#ff9500', 'arrow': '◄── MAJOR'
            })
    
    # Current price marker
    all_levels.append({
        'price': current_price, 'type': 'CURRENT',
        'label': '◄ CURRENT', 'color': '#3b82f6', 'arrow': ''
    })
    
    # Add liquidity lows
    for l in liquidity_levels.get('lows', [])[:3]:
        if l['price'] < current_price:
            all_levels.append({
                'price': l['price'], 'type': 'LIQUIDITY_LOW',
                'label': f"Liquidity Pool ({l.get('strength', 'MODERATE')})", 
                'color': '#00ff88', 'arrow': '◄── SWEEP FOR LONG'
            })
    
    # Add equal lows
    for el in liquidity_levels.get('equal_lows', []):
        if el['price'] < current_price:
            all_levels.append({
                'price': el['price'], 'type': 'EQUAL_LOW',
                'label': f"Equal Low ⭐", 'color': '#ffcc00', 'arrow': '◄── MAJOR'
            })
    
    # Add long liquidation zones
    for liq in liq_zones.get('long_liquidations', [])[:3]:
        all_levels.append({
            'price': liq['price'], 'type': 'LONG_LIQ',
            'label': f"Long Liq ({liq['leverage']}x)", 'color': '#ff6b6b', 'arrow': '◄── RISK'
        })
    
    # Sort by price descending
    all_levels.sort(key=lambda x: x['price'], reverse=True)
    
    # Render
    st.markdown("#### 📊 LIQUIDITY MAP")
    
    for level in all_levels:
        if level['type'] == 'CURRENT':
            st.markdown(f"""<div style='display: flex; justify-content: space-between; align-items: center; 
                padding: 10px; margin: 4px 0; background: #1a1a2e; border-radius: 8px; border: 2px solid #3b82f6;'>
                <span style='color: #fff; font-weight: bold;'>${level['price']:,.2f}</span>
                <span style='color: #3b82f6; font-weight: bold;'>{level['label']}</span>
            </div>""", unsafe_allow_html=True)
        else:
            st.markdown(f"""<div style='display: flex; justify-content: space-between; align-items: center; 
                padding: 8px; margin: 3px 0; background: #0d0d1a; border-radius: 6px;'>
                <span style='color: #ccc;'>${level['price']:,.2f}</span>
                <span style='color: {level["color"]};'>{level['label']} {level['arrow']}</span>
            </div>""", unsafe_allow_html=True)


def render_sweep_status(sweep_status: dict):
    """Render sweep detection status"""
    if not sweep_status.get('detected'):
        st.markdown("""<div style='background: #1a1a2e; border-radius: 10px; padding: 15px; border: 1px solid #444;'>
            <div style='color: #00d4aa; font-weight: bold;'>⏳ No Active Sweep</div>
            <div style='color: #888;'>Waiting for price to sweep a liquidity level and reject...</div>
        </div>""", unsafe_allow_html=True)
        return
    
    direction = sweep_status.get('direction', 'LONG')
    dir_color = '#00ff88' if direction == 'LONG' else '#ff6b6b'
    confidence = sweep_status.get('confidence', 0)
    level_swept = sweep_status.get('level_swept', 0)
    volume_confirmed = sweep_status.get('volume_confirmed', False)
    candles_ago = sweep_status.get('candles_ago', 0)
    
    st.markdown(f"""<div style='background: #0a1a0a; border-radius: 12px; padding: 20px; border: 2px solid {dir_color};'>
        <div style='color: {dir_color}; font-weight: bold; font-size: 1.2em;'>🎯 SWEEP DETECTED - {direction}</div>
        <div style='margin-top: 10px;'>
            <span style='color: #888;'>Confidence:</span>
            <span style='color: {dir_color}; font-weight: bold;'> {confidence}%</span>
        </div>
        <div style='margin-top: 5px;'>
            <span style='color: #888;'>Level:</span>
            <span style='color: #fff;'> ${level_swept:,.2f}</span>
            <span style='color: #888;'> ({candles_ago} candles ago)</span>
        </div>
        <div style='margin-top: 5px;'>
            <span style='color: #888;'>Volume Spike:</span>
            <span style='color: {"#00ff88" if volume_confirmed else "#888"};'>
                {"✓ Yes" if volume_confirmed else "No"}
            </span>
        </div>
    </div>""", unsafe_allow_html=True)


def render_approaching_levels(approaching: dict, atr: float):
    """Render approaching liquidity levels as NEXT TARGETS"""
    if not approaching.get('has_nearby'):
        st.markdown("""<div style='background: #1a1a2e; border-radius: 10px; padding: 15px; border: 1px solid #444;'>
            <div style='color: #888;'>📏 No liquidity targets within range</div>
        </div>""", unsafe_allow_html=True)
        return
    
    st.markdown("#### 🎯 NEXT TARGETS")
    
    # Show next targets clearly
    next_long = approaching.get('next_long_target')
    next_short = approaching.get('next_short_target')
    
    for level in approaching.get('levels', [])[:4]:
        proximity = level.get('proximity', 'APPROACHING')
        prox_config = {
            'IMMINENT': ('#ff6b6b', '🔥 IMMINENT'),
            'CLOSE': ('#ffcc00', '⚡ CLOSE'),
            'APPROACHING': ('#888', '👀 APPROACHING')
        }
        prox_color, prox_text = prox_config.get(proximity, ('#888', '👀'))
        
        direction = level.get('direction_after_sweep', 'LONG')
        dir_color = '#00ff88' if direction == 'LONG' else '#ff6b6b'
        
        # Check if this is the NEXT target for this direction
        is_next = False
        if direction == 'LONG' and next_long and abs(level.get('price', 0) - next_long.get('price', 0)) < 1:
            is_next = True
        elif direction == 'SHORT' and next_short and abs(level.get('price', 0) - next_short.get('price', 0)) < 1:
            is_next = True
        
        # Show when level formed
        formed_ago = level.get('formed_ago', '')
        formed_text = f" • {formed_ago}" if formed_ago else ""
        
        border_style = f"2px solid {dir_color}" if is_next else "1px solid #333"
        
        st.markdown(f"""<div style='display: flex; justify-content: space-between; align-items: center;
            padding: 12px; margin: 4px 0; background: #0d0d1a; border-radius: 8px; border: {border_style};'>
            <div>
                <span style='color: #fff; font-weight: bold;'>${level.get('price', 0):,.2f}</span>
                <span style='color: #666; font-size: 0.8em;'>{formed_text}</span>
            </div>
            <span style='color: {prox_color};'>{prox_text}</span>
            <span style='color: #888;'>{level.get('distance_atr', 0):.1f} ATR</span>
            <span style='color: {dir_color}; font-weight: bold;'>→ {direction}</span>
        </div>""", unsafe_allow_html=True)


def render_trade_plan(trade_plan: dict):
    """Render the generated trade plan with ROI% and R:R"""
    status = trade_plan.get('status', 'NO_SETUP')
    
    if status == 'SWEEP_ENTRY':
        direction = trade_plan.get('direction', 'LONG')
        dir_color = '#00ff88' if 'LONG' in direction else '#ff6b6b'
        entry = trade_plan.get('entry', 0)
        stop_loss = trade_plan.get('stop_loss', 0)
        take_profits = trade_plan.get('take_profits', [])
        confidence = trade_plan.get('confidence', 0)
        
        # ML Quality
        ml_quality = trade_plan.get('ml_quality', '')
        ml_probability = trade_plan.get('ml_probability', 0)
        ml_prediction = trade_plan.get('ml_prediction', {})
        
        # ML quality badge
        ml_badge = ""
        if ml_quality:
            ml_colors = {
                'HIGH_QUALITY': '#00ff88',
                'MEDIUM_QUALITY': '#ffcc00',
                'LOW_QUALITY': '#ff6b6b'
            }
            ml_color = ml_colors.get(ml_quality, '#888')
            ml_icon = '🔥' if ml_quality == 'HIGH_QUALITY' else '⚡' if ml_quality == 'MEDIUM_QUALITY' else '⚠️'
            ml_badge = f"<span style='background: {ml_color}22; padding: 3px 8px; border-radius: 10px; border: 1px solid {ml_color}; margin-left: 10px;'><span style='color: {ml_color};'>{ml_icon} ML: {ml_probability:.0%}</span></span>"
        
        # Calculate SL %
        if entry > 0:
            if 'LONG' in direction:
                sl_pct = ((entry - stop_loss) / entry) * 100
            else:
                sl_pct = ((stop_loss - entry) / entry) * 100
        else:
            sl_pct = 0
        
        st.markdown(f"""<div style='background: #0a1a0a; border-radius: 12px; padding: 20px; border: 2px solid {dir_color};'>
            <div style='display: flex; justify-content: space-between; align-items: center;'>
                <div style='color: {dir_color}; font-weight: bold; font-size: 1.3em;'>🎯 TRADE PLAN - {direction}{ml_badge}</div>
                <div style='background: {dir_color}22; padding: 5px 12px; border-radius: 20px; border: 1px solid {dir_color};'>
                    <span style='color: {dir_color};'>{confidence}% Confidence</span>
                </div>
            </div>
        </div>""", unsafe_allow_html=True)
        
        # ML Factors (if available)
        if ml_prediction and ml_prediction.get('factors'):
            factors = ml_prediction['factors']
            positive = factors.get('positive', [])
            negative = factors.get('negative', [])
            
            factors_html = ""
            if positive:
                factors_html += f"<span style='color: #00ff88;'>✓ {', '.join(positive)}</span>"
            if negative:
                if factors_html:
                    factors_html += " | "
                factors_html += f"<span style='color: #ff6b6b;'>✗ {', '.join(negative)}</span>"
            
            if factors_html:
                st.markdown(f"""<div style='background: #0d0d1a; padding: 8px 15px; border-radius: 6px; margin-top: 5px;'>
                    <span style='color: #888; font-size: 0.85em;'>ML Factors: </span>{factors_html}
                </div>""", unsafe_allow_html=True)
        
        # Entry and Stop Loss
        st.markdown(f"""<div style='display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;'>
            <div style='background: #1a1a2e; padding: 15px; border-radius: 8px; border-left: 3px solid #3b82f6;'>
                <div style='color: #888; font-size: 0.85em;'>ENTRY</div>
                <div style='color: #3b82f6; font-weight: bold; font-size: 1.3em;'>${entry:,.2f}</div>
            </div>
            <div style='background: #1a1a2e; padding: 15px; border-radius: 8px; border-left: 3px solid #ff6b6b;'>
                <div style='color: #888; font-size: 0.85em;'>STOP LOSS</div>
                <div style='color: #ff6b6b; font-weight: bold; font-size: 1.3em;'>${stop_loss:,.2f}</div>
                <div style='color: #ff6b6b; font-size: 0.9em;'>-{sl_pct:.2f}%</div>
            </div>
        </div>""", unsafe_allow_html=True)
        
        # Take Profits with ROI% and R:R
        if take_profits:
            st.markdown("<div style='margin-top: 15px; color: #888; font-size: 0.9em;'>TAKE PROFITS</div>", unsafe_allow_html=True)
            
            for tp in take_profits:
                tp_price = tp.get('price', 0)
                tp_rr = tp.get('rr', 0)
                tp_level = tp.get('level', 1)
                tp_reason = tp.get('reason', '')
                
                # Use roi from trade plan or calculate
                tp_roi = tp.get('roi', 0)
                if tp_roi == 0 and entry > 0:
                    if 'LONG' in direction:
                        tp_roi = ((tp_price - entry) / entry) * 100
                    else:
                        tp_roi = ((entry - tp_price) / entry) * 100
                
                # Color based on R:R
                rr_color = '#00ff88' if tp_rr >= 2 else '#ffcc00' if tp_rr >= 1 else '#ff6b6b'
                
                st.markdown(f"""<div style='display: flex; justify-content: space-between; align-items: center;
                    padding: 12px; margin: 5px 0; background: #0d0d1a; border-radius: 8px; border-left: 3px solid #00d4aa;'>
                    <div>
                        <span style='color: #00d4aa; font-weight: bold;'>TP{tp_level}</span>
                        <span style='color: #fff; font-weight: bold; margin-left: 10px;'>${tp_price:,.2f}</span>
                        <span style='color: #888; margin-left: 10px; font-size: 0.85em;'>{tp_reason}</span>
                    </div>
                    <div style='display: flex; gap: 15px;'>
                        <span style='color: #00ff88; font-weight: bold;'>+{tp_roi:.2f}%</span>
                        <span style='color: {rr_color}; font-weight: bold;'>{tp_rr:.1f}R</span>
                    </div>
                </div>""", unsafe_allow_html=True)
    
    elif status == 'WAITING_FOR_SWEEP':
        # Get the sweep level (the level we're watching)
        sweep_level = trade_plan.get('sweep_level', 0)
        direction = trade_plan.get('direction', 'LONG')
        proximity = trade_plan.get('proximity', 'APPROACHING')
        confidence = trade_plan.get('confidence', 50)
        
        # Get estimated levels
        est_entry = trade_plan.get('est_entry', sweep_level)
        est_sl = trade_plan.get('est_sl', 0)
        est_sl_pct = trade_plan.get('est_sl_pct', 0)
        est_tps = trade_plan.get('est_tps', [])
        
        dir_color = '#00ff88' if 'LONG' in direction else '#ff6b6b'
        prox_color = '#ff6b6b' if proximity == 'IMMINENT' else '#ffcc00' if proximity == 'CLOSE' else '#888'
        
        # Header
        st.markdown(f"""<div style='background: #1a1a2e; border-radius: 12px; padding: 20px; border: 1px solid #3b82f6;'>
            <div style='display: flex; justify-content: space-between; align-items: center;'>
                <div style='color: #3b82f6; font-weight: bold; font-size: 1.1em;'>⏳ WAITING FOR SWEEP</div>
                <div style='display: flex; gap: 10px;'>
                    <span style='background: {prox_color}22; padding: 5px 12px; border-radius: 20px; border: 1px solid {prox_color}; color: {prox_color};'>{proximity}</span>
                    <span style='background: {dir_color}22; padding: 5px 12px; border-radius: 20px; border: 1px solid {dir_color}; color: {dir_color};'>{confidence}%</span>
                </div>
            </div>
        </div>""", unsafe_allow_html=True)
        
        # Estimated Entry and Stop Loss
        st.markdown(f"""<div style='display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;'>
            <div style='background: #0d0d1a; padding: 15px; border-radius: 8px; border-left: 3px solid #3b82f6;'>
                <div style='color: #888; font-size: 0.85em;'>EST. ENTRY (at sweep level)</div>
                <div style='color: #3b82f6; font-weight: bold; font-size: 1.3em;'>${est_entry:,.2f}</div>
            </div>
            <div style='background: #0d0d1a; padding: 15px; border-radius: 8px; border-left: 3px solid #ff6b6b;'>
                <div style='color: #888; font-size: 0.85em;'>EST. STOP LOSS</div>
                <div style='color: #ff6b6b; font-weight: bold; font-size: 1.3em;'>${est_sl:,.2f}</div>
                <div style='color: #ff6b6b; font-size: 0.9em;'>-{est_sl_pct:.2f}%</div>
            </div>
        </div>""", unsafe_allow_html=True)
        
        # Estimated Take Profits with ROI% and R:R
        if est_tps:
            st.markdown("<div style='margin-top: 15px; color: #888; font-size: 0.9em;'>ESTIMATED TAKE PROFITS</div>", unsafe_allow_html=True)
            
            for tp in est_tps:
                tp_price = tp.get('price', 0)
                tp_rr = tp.get('rr', 0)
                tp_roi = tp.get('roi', 0)
                tp_level = tp.get('level', 1)
                tp_reason = tp.get('reason', '')
                
                # Color based on R:R
                rr_color = '#00ff88' if tp_rr >= 2 else '#ffcc00' if tp_rr >= 1 else '#ff6b6b'
                
                st.markdown(f"""<div style='display: flex; justify-content: space-between; align-items: center;
                    padding: 12px; margin: 5px 0; background: #0d0d1a; border-radius: 8px; border-left: 3px solid #00d4aa;'>
                    <div>
                        <span style='color: #00d4aa; font-weight: bold;'>TP{tp_level}</span>
                        <span style='color: #fff; font-weight: bold; margin-left: 10px;'>${tp_price:,.2f}</span>
                        <span style='color: #888; margin-left: 10px; font-size: 0.85em;'>{tp_reason}</span>
                    </div>
                    <div style='display: flex; gap: 15px;'>
                        <span style='color: #00ff88; font-weight: bold;'>+{tp_roi:.2f}%</span>
                        <span style='color: {rr_color}; font-weight: bold;'>{tp_rr:.1f}R</span>
                    </div>
                </div>""", unsafe_allow_html=True)
        
        # Determine sweep direction for instructions
        is_long = 'LONG' in direction
        sweep_word = "below" if is_long else "above"
        close_word = "above" if is_long else "below"
        bg_color = "#1a2a1a" if is_long else "#2a1a1a"
        buy_sell = "BUY" if is_long else "SELL"
        long_short = "LONG" if is_long else "SHORT"
        
        # Entry Options Header
        st.markdown(f"""<div style='margin-top: 15px; background: #0d1117; padding: 15px; border-radius: 8px; border: 1px solid {dir_color};'>
            <div style='color: {dir_color}; font-weight: bold; font-size: 1.1em; margin-bottom: 12px;'>📍 HOW TO ENTER - {direction}</div>
        </div>""", unsafe_allow_html=True)
        
        # Option 1
        st.markdown(f"""<div style='background: {bg_color}; padding: 12px; border-radius: 8px; margin-top: 5px; border-left: 3px solid {dir_color};'>
            <div style='color: {dir_color}; font-weight: bold;'>OPTION 1: LIMIT ORDER (Aggressive)</div>
            <div style='color: #ccc; margin-top: 5px;'>
                ✅ Place limit {buy_sell} at ${sweep_level:,.2f}
            </div>
            <div style='color: #ccc;'>
                ✅ SL at ${est_sl:,.2f} (-{est_sl_pct:.2f}%)
            </div>
            <div style='color: #ffcc00;'>
                ⚠️ Risk: Price may sweep further before reversing
            </div>
        </div>""", unsafe_allow_html=True)
        
        # Option 2
        st.markdown(f"""<div style='background: #1a1a2a; padding: 12px; border-radius: 8px; margin-top: 5px; border-left: 3px solid #3b82f6;'>
            <div style='color: #3b82f6; font-weight: bold;'>OPTION 2: WAIT FOR REJECTION (Safer)</div>
            <div style='color: #ccc; margin-top: 5px;'>
                1️⃣ Wait for price to sweep {sweep_word} ${sweep_level:,.2f}
            </div>
            <div style='color: #ccc;'>
                2️⃣ Wait for candle to CLOSE back {close_word} the level
            </div>
            <div style='color: #ccc;'>
                3️⃣ Enter {long_short} on next candle
            </div>
            <div style='color: #00ff88;'>
                ✅ Higher win rate, might miss some moves
            </div>
        </div>""", unsafe_allow_html=True)
    
    else:
        st.markdown("""<div style='background: #1a1a2e; border-radius: 12px; padding: 20px; border: 1px solid #444;'>
            <div style='color: #888; font-weight: bold;'>📋 NO ACTIVE SETUP</div>
            <div style='color: #666; margin-top: 8px;'>Wait for price to sweep a liquidity level and reject.</div>
            <div style='color: #666; margin-top: 5px; font-size: 0.9em;'>Best setups come AFTER sweeps, not before.</div>
        </div>""", unsafe_allow_html=True)


def render_whale_positioning(liquidation_data: dict, whale_delta: dict = None):
    """Render whale vs retail positioning with change over time"""
    if not liquidation_data.get('success'):
        st.markdown("""<div style='background: #1a1a2e; border-radius: 10px; padding: 15px; border: 1px solid #444;'>
            <div style='color: #888;'>🐋 Whale data unavailable</div>
        </div>""", unsafe_allow_html=True)
        return
    
    whale_long = liquidation_data.get('whale_long', 50)
    whale_short = liquidation_data.get('whale_short', 50)
    retail_long = liquidation_data.get('retail_long', 50)
    funding = liquidation_data.get('funding_rate', 0)
    
    whale_bias = "BULLISH" if whale_long > 55 else ("BEARISH" if whale_short > 55 else "NEUTRAL")
    whale_color = "#00ff88" if whale_long > 55 else ("#ff6b6b" if whale_short > 55 else "#888")
    
    st.markdown("#### 🐋 WHALE POSITIONING")
    
    # Main positioning
    st.markdown(f"""<div style='background: #1a1a2e; border-radius: 10px; padding: 15px;'>
        <div style='display: flex; justify-content: space-between; margin-bottom: 10px;'>
            <span style='color: #888;'>Whales:</span>
            <span style='color: {whale_color}; font-weight: bold;'>{whale_bias} ({whale_long:.0f}% Long)</span>
        </div>
        <div style='display: flex; justify-content: space-between; margin-bottom: 10px;'>
            <span style='color: #888;'>Retail:</span>
            <span style='color: #ccc;'>{retail_long:.0f}% Long</span>
        </div>
        <div style='display: flex; justify-content: space-between;'>
            <span style='color: #888;'>Funding:</span>
            <span style='color: {"#00ff88" if funding < 0 else "#ff6b6b"};'>{funding:.4f}%</span>
        </div>
    </div>""", unsafe_allow_html=True)
    
    # Delta section (separate markdown call)
    if whale_delta and whale_delta.get('data_available'):
        w_delta = whale_delta.get('whale_delta', 0) or 0
        r_delta = whale_delta.get('retail_delta', 0) or 0
        lookback = whale_delta.get('lookback_label', '24h')
        
        w_delta_color = '#00ff88' if w_delta > 0 else '#ff6b6b' if w_delta < 0 else '#888'
        r_delta_color = '#00ff88' if r_delta > 0 else '#ff6b6b' if r_delta < 0 else '#888'
        w_arrow = '↑' if w_delta > 0 else '↓' if w_delta < 0 else '→'
        r_arrow = '↑' if r_delta > 0 else '↓' if r_delta < 0 else '→'
        
        st.markdown(f"""<div style='margin-top: 10px; padding: 10px; background: #0d0d1a; border-radius: 8px;'>
            <div style='color: #888; font-size: 0.9em; margin-bottom: 8px;'>Change ({lookback})</div>
            <div style='display: flex; justify-content: space-between;'>
                <span style='color: #888;'>Whales:</span>
                <span style='color: {w_delta_color}; font-weight: bold;'>{w_arrow} {w_delta:+.1f}%</span>
            </div>
            <div style='display: flex; justify-content: space-between; margin-top: 5px;'>
                <span style='color: #888;'>Retail:</span>
                <span style='color: {r_delta_color};'>{r_arrow} {r_delta:+.1f}%</span>
            </div>
        </div>""", unsafe_allow_html=True)


def render_scanner_results(results: list):
    """Render scanner results with direction indicator and quality badge - NO HTML"""
    if not results:
        st.info("No results to display")
        return
    
    for result in results:
        status = result.get('status', 'MONITORING')
        symbol = result.get('symbol', '')
        current_price = result.get('current_price', 0)
        whale_pct = result.get('whale_pct', 50)
        whale_delta = result.get('whale_delta', 0)
        
        # Get direction from sweep data
        sweep = result.get('sweep', {})
        direction = sweep.get('direction', '') if sweep else ''
        level = sweep.get('level_swept', 0) if sweep else 0
        
        # For approaching, get direction from approaching data
        if not direction and result.get('approaching'):
            direction = result['approaching'].get('direction_after_sweep', '')
        
        # Status emoji
        status_emoji = {
            'SWEEP_ACTIVE': '🎯',
            'IMMINENT': '🔥',
            'APPROACHING': '⚡',
            'MONITORING': '👀'
        }.get(status, '👀')
        
        # Direction emoji
        dir_emoji = '🟢' if direction == 'LONG' else '🔴' if direction == 'SHORT' else ''
        
        # Quality badge
        quality_text = ""
        quality_pred = result.get('quality_prediction')
        if quality_pred:
            prob = quality_pred.get('probability', 0.5)
            decision = quality_pred.get('decision', 'UNKNOWN')
            q_icon = '🔥' if decision == 'STRONG_YES' else '✅' if decision == 'YES' else '⚠️' if decision == 'MAYBE' else '❌'
            quality_text = f"{q_icon} {prob:.0%}"
        
        # Level text
        level_text = f"${level:,.2f}" if level > 0 else ""
        
        # Whale delta indicator
        if whale_delta and whale_delta > 3:
            whale_status = "↑"  # Accumulating
        elif whale_delta and whale_delta < -3:
            whale_status = "↓"  # Distributing
        else:
            whale_status = ""
        
        # Use columns for clean layout
        col1, col2, col3, col4, col5 = st.columns([0.5, 2, 2, 2, 1.5])
        
        with col1:
            st.write(status_emoji)
        with col2:
            st.write(f"**{symbol}**")
            if level_text:
                st.caption(level_text)
        with col3:
            st.write(f"${current_price:,.2f}")
            st.caption(status)
        with col4:
            st.write(f"{dir_emoji} {direction}")
            if quality_text:
                st.caption(quality_text)
        with col5:
            whale_display = f"🐋 {whale_pct:.0f}%{whale_status}"
            st.write(whale_display)
            if whale_delta:
                delta_color = "green" if whale_delta > 0 else "red"
                st.caption(f"{whale_delta:+.1f}%")
        
        st.divider()


def render_liquidity_education():
    """Render educational content"""
    with st.expander("📚 How Liquidity Hunting Works"):
        st.markdown("""
        <div style='color: #fff;'>
            <div style='color: #00d4aa; font-weight: bold; margin-bottom: 10px;'>🎯 The Whale Playbook</div>
            <div style='color: #ccc; margin-bottom: 15px;'>
                Big players need liquidity (your stop losses) to fill their orders.
            </div>
            <div style='color: #3b82f6; font-weight: bold; margin-bottom: 8px;'>The Sweep Cycle:</div>
            <div style='color: #ccc; margin-left: 15px;'>
                1️⃣ Find where stops cluster (swing lows/highs)<br>
                2️⃣ Price pushed through to trigger stops<br>
                3️⃣ Whales fill orders against triggered stops<br>
                4️⃣ Price reverses sharply (the "sweep")<br>
                5️⃣ Real direction revealed
            </div>
            <div style='color: #ffcc00; font-weight: bold; margin-top: 15px;'>⭐ Equal Lows/Highs = Maximum Liquidity</div>
            <div style='color: #ccc;'>Multiple touches = more stops = higher probability sweep target.</div>
        </div>
        """, unsafe_allow_html=True)


def render_scanner_controls():
    """
    Render scanner control panel with filters.
    Returns: dict with scan_count, direction_filter
    """
    st.markdown("#### ⚙️ Scanner Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        scan_count = st.select_slider(
            "Symbols to Scan",
            options=[10, 20, 50, 100],
            value=20,
            help="More symbols = longer scan time"
        )
    
    with col2:
        direction_filter = st.selectbox(
            "Direction Filter",
            options=["ALL", "LONG ONLY", "SHORT ONLY"],
            index=1,  # Default to LONG ONLY
            help="Filter results by trade direction"
        )
    
    # Status filter
    col3, col4 = st.columns(2)
    
    with col3:
        status_filter = st.multiselect(
            "Status Filter",
            options=["SWEEP_ACTIVE", "IMMINENT", "APPROACHING", "MONITORING"],
            default=["SWEEP_ACTIVE", "IMMINENT", "APPROACHING"],
            help="Show only selected statuses"
        )
    
    with col4:
        min_whale_pct = st.slider(
            "Min Whale %",
            min_value=40,
            max_value=80,
            value=50,
            help="Only show symbols with whale % above this"
        )
    
    return {
        'scan_count': scan_count,
        'direction_filter': direction_filter,
        'status_filter': status_filter,
        'min_whale_pct': min_whale_pct
    }


def filter_scanner_results(results: list, filters: dict) -> list:
    """Apply filters to scanner results"""
    filtered = []
    
    direction_filter = filters.get('direction_filter', 'ALL')
    status_filter = filters.get('status_filter', [])
    min_whale_pct = filters.get('min_whale_pct', 50)
    
    for result in results:
        # Direction filter
        sweep = result.get('sweep', {})
        approaching = result.get('approaching', {})
        
        direction = None
        if sweep:
            direction = sweep.get('direction')
        elif approaching:
            direction = approaching.get('direction_after_sweep')
        
        if direction_filter == "LONG ONLY" and direction != "LONG":
            continue
        if direction_filter == "SHORT ONLY" and direction != "SHORT":
            continue
        
        # Status filter
        if status_filter and result.get('status') not in status_filter:
            continue
        
        # Whale % filter
        if result.get('whale_pct', 50) < min_whale_pct:
            continue
        
        filtered.append(result)
    
    return filtered


def render_ml_training_panel():
    """Render ML training and stats panel"""
    st.markdown("#### 🤖 ML Model Training")
    
    # Try to import ML module
    try:
        from .liquidity_hunter_ml import get_training_stats, get_predictor
    except ImportError:
        try:
            from liquidity_hunter_ml import get_training_stats, get_predictor
        except ImportError:
            st.warning("ML module not available")
            return
    
    # Get training stats
    stats = get_training_stats()
    
    # Display stats
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Trades", stats.get('total_trades', 0))
    with col2:
        st.metric("Wins", stats.get('wins', 0), delta=None)
    with col3:
        st.metric("Losses", stats.get('losses', 0), delta=None)
    with col4:
        win_rate = stats.get('win_rate', 0)
        st.metric("Win Rate", f"{win_rate:.1%}" if win_rate > 0 else "N/A")
    
    # Training status
    predictor = get_predictor()
    model_status = "✅ Model Loaded" if predictor.model is not None else "⚠️ No Model (Rule-based)"
    
    st.markdown(f"""<div style='background: #1a1a2e; padding: 15px; border-radius: 8px; margin: 10px 0;'>
        <div style='color: #fff;'>Status: {model_status}</div>
        <div style='color: #888; font-size: 0.9em;'>Pending trades: {stats.get('pending', 0)}</div>
    </div>""", unsafe_allow_html=True)
    
    # Training button
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🔄 Train Model", use_container_width=True):
            if stats.get('wins', 0) + stats.get('losses', 0) < 50:
                st.warning(f"Need at least 50 completed trades. Have {stats.get('wins', 0) + stats.get('losses', 0)}")
            else:
                with st.spinner("Training model..."):
                    metrics = predictor.train()
                    if 'error' in metrics:
                        st.error(metrics['error'])
                    else:
                        st.success(f"Model trained! F1: {metrics.get('f1_score', 0):.3f}")
                        st.json(metrics)
    
    with col2:
        if st.button("📊 View Feature Importance", use_container_width=True):
            if predictor.model is not None:
                try:
                    importance = dict(zip(
                        predictor.feature_names[:len(predictor.model.feature_importances_)],
                        predictor.model.feature_importances_
                    ))
                    # Sort by importance
                    importance = dict(sorted(importance.items(), key=lambda x: x[1], reverse=True))
                    
                    st.markdown("**Top Features:**")
                    for feat, imp in list(importance.items())[:10]:
                        bar_width = int(imp * 300)
                        st.markdown(f"""<div style='display: flex; align-items: center; margin: 3px 0;'>
                            <span style='color: #888; width: 150px;'>{feat}</span>
                            <div style='background: #3b82f6; height: 12px; width: {bar_width}px; border-radius: 3px;'></div>
                            <span style='color: #fff; margin-left: 10px;'>{imp:.3f}</span>
                        </div>""", unsafe_allow_html=True)
                except Exception as e:
                    st.error(f"Error: {e}")
            else:
                st.info("No model trained yet")


def render_ml_prediction_badge(ml_prediction: dict):
    """Render a compact ML prediction badge"""
    if not ml_prediction:
        return ""
    
    quality = ml_prediction.get('prediction', 'UNKNOWN')
    probability = ml_prediction.get('probability', 0)
    
    colors = {
        'HIGH_QUALITY': '#00ff88',
        'MEDIUM_QUALITY': '#ffcc00',
        'LOW_QUALITY': '#ff6b6b'
    }
    icons = {
        'HIGH_QUALITY': '🔥',
        'MEDIUM_QUALITY': '⚡',
        'LOW_QUALITY': '⚠️'
    }
    
    color = colors.get(quality, '#888')
    icon = icons.get(quality, '❓')
    
    return f"""<span style='background: {color}22; padding: 3px 8px; border-radius: 10px; 
        border: 1px solid {color}; font-size: 0.85em;'>
        <span style='color: {color};'>{icon} {probability:.0%}</span>
    </span>"""
