"""
Quality-Based Liquidity Hunter ML
==================================
SIMPLE approach: Predict "Should I take this trade?" (YES/NO)

Instead of predicting sweep outcomes, we FILTER for high-quality setups.

Key insight from user:
- Whale 65% (was 45%) = ACCUMULATING = ✅ BULLISH
- Whale 65% (was 85%) = DISTRIBUTING = ❌ BEARISH TRAP

The CHANGE matters more than absolute value!
"""

import os
import pickle
import sqlite3
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

MODEL_PATH = "models/quality_model.pkl"
LOOKBACK_CANDLES = 50
FORWARD_CANDLES = 20  # Shorter - we want quick trades

# Minimum R:R to consider a "winning" trade
MIN_RR_FOR_WIN = 1.0  # Must hit at least 1:1

# ═══════════════════════════════════════════════════════════════════════════════
# WHALE ANALYSIS - THE KEY INSIGHT!
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_whale_behavior(whale_pct: float, whale_delta: float, direction: str) -> Dict:
    """
    Analyze whale behavior - CHANGE matters more than absolute!
    
    Args:
        whale_pct: Current whale long % (0-100)
        whale_delta: Change in whale % (positive = more long, negative = less long)
        direction: 'LONG' or 'SHORT'
    
    Returns:
        Dict with whale analysis
    """
    # Determine whale behavior
    if whale_delta > 5:
        behavior = 'ACCUMULATING'  # Whales buying
    elif whale_delta < -5:
        behavior = 'DISTRIBUTING'  # Whales selling
    else:
        behavior = 'NEUTRAL'
    
    # Is whale aligned with trade direction?
    if direction == 'LONG':
        # For LONG: Want whales bullish AND accumulating
        whale_bullish = whale_pct >= 55
        whale_aligned = whale_bullish and whale_delta >= 0
        whale_strong = whale_pct >= 65 and whale_delta > 3
        whale_trap = whale_pct >= 60 and whale_delta < -5  # High but dropping = TRAP!
    else:
        # For SHORT: Want whales bearish AND distributing
        whale_bearish = whale_pct <= 45
        whale_aligned = whale_bearish and whale_delta <= 0
        whale_strong = whale_pct <= 35 and whale_delta < -3
        whale_trap = whale_pct <= 40 and whale_delta > 5  # Low but rising = TRAP!
    
    # Quality score based on whale behavior
    quality = 0
    
    if direction == 'LONG':
        if whale_pct >= 70 and whale_delta > 0:
            quality = 1.0  # Perfect: High and rising
        elif whale_pct >= 60 and whale_delta >= 0:
            quality = 0.8  # Good: Decent and stable/rising
        elif whale_pct >= 55 and whale_delta > 5:
            quality = 0.7  # OK: Medium but accelerating
        elif whale_pct >= 50 and whale_delta > 0:
            quality = 0.5  # Neutral but rising
        elif whale_delta < -5:
            quality = 0.1  # Bad: Distributing (regardless of %)
        else:
            quality = 0.3
    else:  # SHORT
        if whale_pct <= 30 and whale_delta < 0:
            quality = 1.0  # Perfect: Low and dropping
        elif whale_pct <= 40 and whale_delta <= 0:
            quality = 0.8  # Good: Decent and stable/dropping
        elif whale_pct <= 45 and whale_delta < -5:
            quality = 0.7  # OK: Medium but accelerating down
        elif whale_pct <= 50 and whale_delta < 0:
            quality = 0.5  # Neutral but dropping
        elif whale_delta > 5:
            quality = 0.1  # Bad: Accumulating (regardless of %)
        else:
            quality = 0.3
    
    return {
        'whale_pct': whale_pct,
        'whale_delta': whale_delta,
        'behavior': behavior,
        'aligned': whale_aligned,
        'strong': whale_strong,
        'trap': whale_trap,
        'quality': quality
    }


# ═══════════════════════════════════════════════════════════════════════════════
# LEVEL QUALITY ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

def analyze_level_quality(level_type: str, level_strength: float, distance_atr: float) -> Dict:
    """
    Analyze if level is worth trading.
    
    Only trade STRONG levels (EQUAL, DOUBLE) that are CLOSE.
    """
    # Level type scoring
    type_scores = {
        'EQUAL_LOW': 1.0,
        'EQUAL_HIGH': 1.0,
        'DOUBLE_LOW': 0.8,
        'DOUBLE_HIGH': 0.8,
        '100X_LIQ': 1.0,
        '50X_LIQ': 0.85,
        '25X_LIQ': 0.7,
        'SWING_LOW': 0.4,  # Low - usually noise
        'SWING_HIGH': 0.4,
    }
    
    type_score = type_scores.get(level_type, 0.3)
    
    # Distance scoring - closer is better
    if distance_atr <= 0.5:
        distance_score = 1.0  # Very close - immediate opportunity
    elif distance_atr <= 1.0:
        distance_score = 0.9
    elif distance_atr <= 1.5:
        distance_score = 0.7
    elif distance_atr <= 2.0:
        distance_score = 0.5
    elif distance_atr <= 3.0:
        distance_score = 0.3
    else:
        distance_score = 0.1  # Too far
    
    # Combined quality
    quality = (type_score * 0.6) + (distance_score * 0.4)
    
    # Is this a tradeable level?
    tradeable = (
        type_score >= 0.7 and  # EQUAL or DOUBLE only
        distance_atr <= 2.5 and  # Within range
        quality >= 0.5
    )
    
    return {
        'level_type': level_type,
        'type_score': type_score,
        'distance_atr': distance_atr,
        'distance_score': distance_score,
        'quality': quality,
        'tradeable': tradeable
    }


# ═══════════════════════════════════════════════════════════════════════════════
# SHOULD I TAKE THIS TRADE? (Main Decision Function)
# ═══════════════════════════════════════════════════════════════════════════════

def should_take_trade(
    level_type: str,
    level_strength: float,
    distance_atr: float,
    whale_pct: float,
    whale_delta: float,
    direction: str,
    momentum: float = 0,
    volume_ratio: float = 1.0
) -> Dict:
    """
    Simple decision: Should I take this trade?
    
    This is the CORE function - combines whale + level analysis.
    
    Returns:
        Dict with decision and reasoning
    """
    whale = analyze_whale_behavior(whale_pct, whale_delta, direction)
    level = analyze_level_quality(level_type, level_strength, distance_atr)
    
    # Start with base score
    score = 0
    reasons = []
    red_flags = []
    
    # ═══════════════════════════════════════════════════════════════════
    # WHALE ANALYSIS (50% weight)
    # ═══════════════════════════════════════════════════════════════════
    
    if whale['trap']:
        score -= 30
        red_flags.append(f"⚠️ WHALE TRAP: {whale_pct:.0f}% but delta {whale_delta:+.1f}%")
    
    if whale['strong']:
        score += 25
        reasons.append(f"✅ Strong whale alignment: {whale_pct:.0f}% delta {whale_delta:+.1f}%")
    elif whale['aligned']:
        score += 15
        reasons.append(f"✅ Whale aligned: {whale_pct:.0f}%")
    
    if whale['behavior'] == 'ACCUMULATING' and direction == 'LONG':
        score += 10
        reasons.append("📈 Whales accumulating")
    elif whale['behavior'] == 'DISTRIBUTING' and direction == 'SHORT':
        score += 10
        reasons.append("📉 Whales distributing")
    elif whale['behavior'] == 'ACCUMULATING' and direction == 'SHORT':
        score -= 15
        red_flags.append("⚠️ Shorting while whales accumulate!")
    elif whale['behavior'] == 'DISTRIBUTING' and direction == 'LONG':
        score -= 15
        red_flags.append("⚠️ Longing while whales distribute!")
    
    # Whale quality contribution
    score += whale['quality'] * 20
    
    # ═══════════════════════════════════════════════════════════════════
    # LEVEL ANALYSIS (30% weight)
    # ═══════════════════════════════════════════════════════════════════
    
    if not level['tradeable']:
        score -= 20
        red_flags.append(f"⚠️ Weak level: {level_type} @ {distance_atr:.1f} ATR")
    
    if level['type_score'] >= 0.9:
        score += 15
        reasons.append(f"✅ Strong level: {level_type}")
    elif level['type_score'] >= 0.7:
        score += 10
        reasons.append(f"✅ Good level: {level_type}")
    
    if level['distance_score'] >= 0.8:
        score += 10
        reasons.append(f"✅ Close to level: {distance_atr:.1f} ATR")
    elif level['distance_atr'] > 2.5:
        score -= 10
        red_flags.append(f"⚠️ Too far: {distance_atr:.1f} ATR")
    
    # ═══════════════════════════════════════════════════════════════════
    # MOMENTUM (10% weight)
    # ═══════════════════════════════════════════════════════════════════
    
    if direction == 'LONG' and momentum > 0.3:
        score += 5
        reasons.append("📈 Momentum supportive")
    elif direction == 'SHORT' and momentum < -0.3:
        score += 5
        reasons.append("📉 Momentum supportive")
    elif direction == 'LONG' and momentum < -0.5:
        score -= 5
        red_flags.append("⚠️ Fighting momentum")
    elif direction == 'SHORT' and momentum > 0.5:
        score -= 5
        red_flags.append("⚠️ Fighting momentum")
    
    # ═══════════════════════════════════════════════════════════════════
    # VOLUME (10% weight)
    # ═══════════════════════════════════════════════════════════════════
    
    if volume_ratio > 1.5:
        score += 5
        reasons.append("📊 High volume")
    elif volume_ratio < 0.5:
        score -= 5
        red_flags.append("⚠️ Low volume")
    
    # ═══════════════════════════════════════════════════════════════════
    # FINAL DECISION
    # ═══════════════════════════════════════════════════════════════════
    
    # Normalize score to 0-100
    score = max(0, min(100, score + 50))  # Base 50, range 0-100
    
    # Decision thresholds
    if score >= 70:
        decision = 'STRONG_YES'
        take_trade = True
    elif score >= 55:
        decision = 'YES'
        take_trade = True
    elif score >= 45:
        decision = 'MAYBE'
        take_trade = False  # Skip marginal setups
    else:
        decision = 'NO'
        take_trade = False
    
    return {
        'take_trade': take_trade,
        'decision': decision,
        'score': score,
        'whale_analysis': whale,
        'level_analysis': level,
        'reasons': reasons,
        'red_flags': red_flags
    }


# ═══════════════════════════════════════════════════════════════════════════════
# FEATURE EXTRACTION FOR ML
# ═══════════════════════════════════════════════════════════════════════════════

def extract_quality_features(
    df: pd.DataFrame,
    level_price: float,
    level_type: str,
    level_strength: float,
    direction: str,
    whale_pct: float,
    whale_delta: float
) -> Dict:
    """
    Extract features for quality prediction model.
    """
    if df is None or len(df) < 20:
        return None
    
    try:
        # Normalize columns
        df.columns = [c.lower() for c in df.columns]
        
        current_price = float(df['close'].iloc[-1])
        
        # ATR
        high = df['high']
        low = df['low']
        close = df['close']
        tr = pd.concat([high - low, abs(high - close.shift(1)), abs(low - close.shift(1))], axis=1).max(axis=1)
        atr = float(tr.rolling(14).mean().iloc[-1])
        
        if atr <= 0:
            return None
        
        # Distance to level
        distance = abs(current_price - level_price)
        distance_atr = distance / atr
        
        # Momentum (price change over 10 candles)
        if len(df) >= 10:
            momentum = (current_price - df['close'].iloc[-10]) / (atr * 10)
        else:
            momentum = 0
        
        # Volume ratio
        if 'volume' in df.columns and len(df) >= 20:
            avg_vol = df['volume'].iloc[-20:].mean()
            recent_vol = df['volume'].iloc[-3:].mean()
            volume_ratio = recent_vol / avg_vol if avg_vol > 0 else 1.0
        else:
            volume_ratio = 1.0
        
        # Volatility (ATR ratio to price)
        volatility = atr / current_price
        
        # Whale features
        whale = analyze_whale_behavior(whale_pct, whale_delta, direction)
        
        # Level features
        level = analyze_level_quality(level_type, level_strength, distance_atr)
        
        return {
            # Core features
            'distance_atr': distance_atr,
            'momentum': momentum,
            'volume_ratio': volume_ratio,
            'volatility': volatility,
            
            # Whale features (THE KEY!)
            'whale_pct': whale_pct,
            'whale_delta': whale_delta,
            'whale_quality': whale['quality'],
            'whale_aligned': 1 if whale['aligned'] else 0,
            'whale_strong': 1 if whale['strong'] else 0,
            'whale_trap': 1 if whale['trap'] else 0,
            'whale_accumulating': 1 if whale['behavior'] == 'ACCUMULATING' else 0,
            'whale_distributing': 1 if whale['behavior'] == 'DISTRIBUTING' else 0,
            
            # Level features
            'level_type_score': level['type_score'],
            'level_distance_score': level['distance_score'],
            'level_quality': level['quality'],
            'level_tradeable': 1 if level['tradeable'] else 0,
            
            # Direction encoding
            'is_long': 1 if direction == 'LONG' else 0,
        }
        
    except Exception as e:
        print(f"[QUALITY_ML] Feature extraction error: {e}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# LABEL: DID THIS TRADE WIN? (Simple 1:1 R:R)
# ═══════════════════════════════════════════════════════════════════════════════

def label_trade_outcome(
    df: pd.DataFrame,
    idx: int,
    level_price: float,
    direction: str,
    atr: float
) -> Optional[Dict]:
    """
    Simple outcome labeling: Did trade hit 1:1 R:R?
    
    Entry: After sweep confirmation (close back above/below level)
    Stop: 0.5 ATR beyond level
    Target: 1:1 R:R (same distance as stop)
    """
    if idx + FORWARD_CANDLES >= len(df):
        return None
    
    current_price = df['close'].iloc[idx]
    
    # Define trade levels
    if direction == 'LONG':
        # Entry after sweep of low
        stop_price = level_price - (0.5 * atr)
        risk = current_price - stop_price
        target_price = current_price + risk  # 1:1 R:R
    else:
        # Entry after sweep of high
        stop_price = level_price + (0.5 * atr)
        risk = stop_price - current_price
        target_price = current_price - risk  # 1:1 R:R
    
    # Track outcome
    sweep_occurred = False
    entry_price = None
    hit_target = False
    hit_stop = False
    max_favorable = 0
    max_adverse = 0
    
    for i in range(1, FORWARD_CANDLES):
        candle = df.iloc[idx + i]
        
        if direction == 'LONG':
            # Check for sweep
            if not sweep_occurred:
                if candle['low'] <= level_price and candle['close'] > level_price:
                    sweep_occurred = True
                    entry_price = candle['close']
            
            # After entry, track outcome
            if sweep_occurred and entry_price:
                favorable = candle['high'] - entry_price
                adverse = entry_price - candle['low']
                max_favorable = max(max_favorable, favorable)
                max_adverse = max(max_adverse, adverse)
                
                if candle['high'] >= target_price:
                    hit_target = True
                    break
                if candle['low'] <= stop_price:
                    hit_stop = True
                    break
        else:
            # SHORT
            if not sweep_occurred:
                if candle['high'] >= level_price and candle['close'] < level_price:
                    sweep_occurred = True
                    entry_price = candle['close']
            
            if sweep_occurred and entry_price:
                favorable = entry_price - candle['low']
                adverse = candle['high'] - entry_price
                max_favorable = max(max_favorable, favorable)
                max_adverse = max(max_adverse, adverse)
                
                if candle['low'] <= target_price:
                    hit_target = True
                    break
                if candle['high'] >= stop_price:
                    hit_stop = True
                    break
    
    if not sweep_occurred:
        return None
    
    # Calculate actual R:R achieved
    actual_rr = max_favorable / max_adverse if max_adverse > 0 else 0
    
    return {
        'sweep_occurred': True,
        'hit_target': hit_target,
        'hit_stop': hit_stop,
        'won': hit_target and not hit_stop,
        'actual_rr': actual_rr,
        'max_favorable': max_favorable,
        'max_adverse': max_adverse,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# QUALITY MODEL CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class QualityModel:
    """
    Simple quality prediction model.
    
    Predicts: "Is this a high-quality setup?" (YES/NO)
    Target: >50% win rate at 1:1 R:R = profitable!
    """
    
    FEATURE_COLS = [
        'distance_atr',
        'momentum',
        'volume_ratio',
        'volatility',
        'whale_pct',
        'whale_delta',
        'whale_quality',
        'whale_aligned',
        'whale_strong',
        'whale_trap',
        'whale_accumulating',
        'whale_distributing',
        'level_type_score',
        'level_distance_score',
        'level_quality',
        'level_tradeable',
        'is_long',
    ]
    
    def __init__(self):
        self.model = None
        self.metrics = {}
        self.is_trained = False
    
    def train(self, samples: List[Dict], training_days: int = 180) -> Dict:
        """
        Train the quality model.
        
        Args:
            samples: List of training samples
            training_days: Actual number of days used for training
        
        Label: 1 = Trade won (hit 1:1 target), 0 = Trade lost
        """
        if len(samples) < 100:
            return {'error': f'Need at least 100 samples, got {len(samples)}'}
        
        print(f"\n{'='*60}")
        print(f"[QUALITY_ML] Training on {len(samples)} samples")
        print(f"{'='*60}")
        
        # Convert to DataFrame
        df = pd.DataFrame(samples)
        
        # Filter to only samples with outcomes
        df = df[df['sweep_occurred'] == True].copy()
        print(f"[QUALITY_ML] Samples with sweeps: {len(df)}")
        
        if len(df) < 50:
            return {'error': f'Need at least 50 sweep samples, got {len(df)}'}
        
        # Prepare features
        available_features = [f for f in self.FEATURE_COLS if f in df.columns]
        X = df[available_features].fillna(0)
        
        # Label: Did the trade WIN? (1:1 R:R or better)
        y = (df['won'] == True).astype(int)
        
        print(f"[QUALITY_ML] Win rate in data: {y.mean():.1%}")
        print(f"[QUALITY_ML] Features: {len(available_features)}")
        
        # Split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Train Gradient Boosting (better for imbalanced)
        self.model = GradientBoostingClassifier(
            n_estimators=100,
            max_depth=4,
            min_samples_leaf=20,
            random_state=42
        )
        self.model.fit(X_train, y_train)
        
        # Evaluate
        y_pred = self.model.predict(X_test)
        y_prob = self.model.predict_proba(X_test)[:, 1]
        
        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, zero_division=0)
        recall = recall_score(y_test, y_pred, zero_division=0)
        
        # Feature importance
        feature_importance = dict(zip(available_features, self.model.feature_importances_))
        top_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)[:10]
        
        # Calculate expected performance
        # If we only take trades where model says "YES" (prob > 0.5)
        high_conf_mask = y_prob >= 0.5
        if high_conf_mask.sum() > 0:
            high_conf_win_rate = y_test[high_conf_mask].mean()
            high_conf_trades = high_conf_mask.sum()
        else:
            high_conf_win_rate = 0
            high_conf_trades = 0
        
        # Very high confidence (prob > 0.6)
        very_high_mask = y_prob >= 0.6
        if very_high_mask.sum() > 0:
            very_high_win_rate = y_test[very_high_mask].mean()
            very_high_trades = very_high_mask.sum()
        else:
            very_high_win_rate = 0
            very_high_trades = 0
        
        # ═══════════════════════════════════════════════════════════════
        # CRITICAL: Trade frequency and duration analysis
        # ═══════════════════════════════════════════════════════════════
        
        # Get ALL predictions on full dataset (not just test)
        X_full = df[available_features].fillna(0)
        y_full_prob = self.model.predict_proba(X_full)[:, 1]
        
        # Count high/very high confidence trades in FULL dataset
        full_high_conf = (y_full_prob >= 0.5).sum()
        full_very_high = (y_full_prob >= 0.6).sum()
        
        # Use the actual training_days passed to this function
        # (training_days is a parameter of the train() method)
        
        # Estimate trades per month
        # CORRECT: Just divide total trades by number of months
        months_of_training = training_days / 30
        
        if months_of_training > 0:
            very_high_per_month = full_very_high / months_of_training
            high_conf_per_month = full_high_conf / months_of_training
        else:
            very_high_per_month = 0
            high_conf_per_month = 0
        
        # Monthly ROI = ROI per trade × trades per month
        # At 1% risk: If win rate is 68%, ROI = 36.4% OF THE 1% RISK = 0.364%
        # Monthly = 0.364% × trades_per_month
        if very_high_win_rate > 0:
            roi_per_trade_pct = (2 * very_high_win_rate - 1) * 100  # e.g., 28.8%
            # At 1% risk per trade, actual gain = roi_per_trade_pct * 0.01 = 0.288%
            monthly_roi_very_high = (roi_per_trade_pct / 100) * very_high_per_month  # e.g., 0.288 × 48 = 13.8%
        else:
            monthly_roi_very_high = 0
        
        if high_conf_win_rate > 0:
            roi_per_trade_high = (2 * high_conf_win_rate - 1) * 100
            monthly_roi_high = (roi_per_trade_high / 100) * high_conf_per_month
        else:
            monthly_roi_high = 0
        
        self.metrics = {
            'accuracy': accuracy,
            'f1': f1,
            'precision': precision,
            'recall': recall,
            'total_samples': len(df),
            'sweep_samples': len(df),
            'base_win_rate': y.mean(),
            'high_conf_win_rate': high_conf_win_rate,
            'high_conf_trades': high_conf_trades,  # In test set
            'high_conf_trades_full': full_high_conf,  # In FULL dataset
            'very_high_win_rate': very_high_win_rate,
            'very_high_trades': very_high_trades,  # In test set
            'very_high_trades_full': full_very_high,  # In FULL dataset
            'features_used': len(available_features),
            'top_features': top_features,
            'trained_at': datetime.now().isoformat(),
            # Trade frequency
            'training_days_est': training_days,
            'very_high_per_month': very_high_per_month,
            'high_conf_per_month': high_conf_per_month,
            # Monthly projections
            'monthly_roi_very_high': monthly_roi_very_high,
            'monthly_roi_high': monthly_roi_high,
        }
        
        # Calculate expected ROI
        # At 1:1 R:R: ROI = Win% - Loss% = Win% - (1 - Win%) = 2*Win% - 1
        base_roi = 2 * y.mean() - 1
        high_conf_roi = 2 * high_conf_win_rate - 1 if high_conf_win_rate > 0 else 0
        very_high_roi = 2 * very_high_win_rate - 1 if very_high_win_rate > 0 else 0
        
        self.metrics['base_roi_per_trade'] = base_roi * 100
        self.metrics['high_conf_roi_per_trade'] = high_conf_roi * 100
        self.metrics['very_high_roi_per_trade'] = very_high_roi * 100
        
        self.is_trained = True
        
        # Save model
        self._save()
        
        print(f"\n{'='*60}")
        print(f"[QUALITY_ML] TRAINING COMPLETE!")
        print(f"{'='*60}")
        print(f"Accuracy: {accuracy:.1%}")
        print(f"F1 Score: {f1:.1%}")
        print(f"")
        print(f"Base Win Rate: {y.mean():.1%} → ROI: {base_roi*100:.1f}%")
        print(f"High Conf (>50%) Win Rate: {high_conf_win_rate:.1%} ({high_conf_trades} test / {full_high_conf} total) → ROI: {high_conf_roi*100:.1f}%")
        print(f"Very High (>60%) Win Rate: {very_high_win_rate:.1%} ({very_high_trades} test / {full_very_high} total) → ROI: {very_high_roi*100:.1f}%")
        print(f"")
        print(f"Trade Frequency:")
        print(f"  Training period: ~{training_days:.0f} days")
        print(f"  Very High trades/month: ~{very_high_per_month:.1f}")
        print(f"  High Conf trades/month: ~{high_conf_per_month:.1f}")
        print(f"")
        print(f"Monthly ROI Projection (at 1:1 R:R, 1% risk):")
        print(f"  Very High only: {monthly_roi_very_high:.1f}%")
        print(f"  High Conf only: {monthly_roi_high:.1f}%")
        print(f"")
        print(f"Top Features:")
        for feat, imp in top_features[:5]:
            print(f"  {feat}: {imp:.3f}")
        
        return self.metrics
    
    def predict(self, features: Dict) -> Dict:
        """
        Predict if this is a quality setup.
        """
        if not self.is_trained:
            self._load()
        
        if self.model is None:
            return {'error': 'Model not trained'}
        
        # Prepare features
        X = pd.DataFrame([features])[self.FEATURE_COLS].fillna(0)
        
        prob = self.model.predict_proba(X)[0][1]
        
        if prob >= 0.6:
            decision = 'STRONG_YES'
            take_trade = True
        elif prob >= 0.5:
            decision = 'YES'
            take_trade = True
        elif prob >= 0.4:
            decision = 'MAYBE'
            take_trade = False
        else:
            decision = 'NO'
            take_trade = False
        
        return {
            'probability': prob,
            'decision': decision,
            'take_trade': take_trade,
            'expected_win_rate': prob,
            'expected_roi': (2 * prob - 1) * 100  # At 1:1 R:R
        }
    
    def _save(self):
        """Save model to disk."""
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        with open(MODEL_PATH, 'wb') as f:
            pickle.dump({
                'model': self.model,
                'metrics': self.metrics,
                'is_trained': self.is_trained
            }, f)
        print(f"[QUALITY_ML] Model saved to {MODEL_PATH}")
    
    def _load(self):
        """Load model from disk."""
        if os.path.exists(MODEL_PATH):
            with open(MODEL_PATH, 'rb') as f:
                data = pickle.load(f)
                self.model = data['model']
                self.metrics = data['metrics']
                self.is_trained = data['is_trained']
            print(f"[QUALITY_ML] Model loaded from {MODEL_PATH}")
        else:
            print(f"[QUALITY_ML] No saved model found")


# Global instance
_quality_model = None

def get_quality_model() -> QualityModel:
    global _quality_model
    if _quality_model is None:
        _quality_model = QualityModel()
        _quality_model._load()
    return _quality_model


def get_quality_model_status() -> Dict:
    """Get current model status."""
    model = get_quality_model()
    return {
        'is_trained': model.is_trained,
        'metrics': model.metrics
    }


# ═══════════════════════════════════════════════════════════════════════════════
# TRAINING DATA GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

def generate_quality_samples(
    df: pd.DataFrame,
    symbol: str,
    whale_history: List[Dict] = None
) -> List[Dict]:
    """
    Generate training samples for quality model.
    
    Only includes STRONG levels (EQUAL, DOUBLE).
    """
    if df is None or len(df) < LOOKBACK_CANDLES + FORWARD_CANDLES + 50:
        print(f"[QUALITY_ML] {symbol}: Not enough data ({len(df) if df is not None else 0} candles)")
        return []
    
    # Normalize
    df = df.copy()
    df.columns = [c.lower() for c in df.columns]
    
    # Calculate ATR
    high = df['high']
    low = df['low']
    close = df['close']
    tr = pd.concat([high - low, abs(high - close.shift(1)), abs(low - close.shift(1))], axis=1).max(axis=1)
    df['atr'] = tr.rolling(14).mean()
    
    atr_current = df['atr'].iloc[-1]
    if pd.isna(atr_current) or atr_current <= 0:
        atr_current = df['close'].iloc[-1] * 0.02
    
    # Find liquidity levels using BUILT-IN function
    liq_levels = _find_liquidity_levels_simple(df, atr_current)
    
    # Count by type
    all_levels = liq_levels['lows'] + liq_levels['highs']
    equal_count = sum(1 for _, _, t, _ in all_levels if 'EQUAL' in t)
    double_count = sum(1 for _, _, t, _ in all_levels if 'DOUBLE' in t)
    swing_count = sum(1 for _, _, t, _ in all_levels if 'SWING' in t)
    
    print(f"[QUALITY_ML] {symbol}: {equal_count} EQUAL, {double_count} DOUBLE, {swing_count} SWING levels")
    
    if equal_count + double_count == 0:
        print(f"[QUALITY_ML] {symbol}: No EQUAL/DOUBLE levels found, including SWING levels for training")
    
    samples = []
    
    # Get whale data with delta calculation
    def get_whale_at_time(idx):
        whale_pct = 50
        whale_delta = 0
        if whale_history and len(whale_history) > 0:
            # Find whale reading closest to this index
            for i, wh in enumerate(whale_history):
                whale_pct = wh.get('whale_pct', wh.get('whale_long_pct', 50))
                # Calculate delta from previous reading
                if i > 0:
                    prev_whale = whale_history[i-1].get('whale_pct', whale_history[i-1].get('whale_long_pct', 50))
                    whale_delta = whale_pct - prev_whale
        return whale_pct, whale_delta
    
    # Process each candle
    for i in range(LOOKBACK_CANDLES + 20, len(df) - FORWARD_CANDLES):
        current_price = df['close'].iloc[i]
        atr = df['atr'].iloc[i]
        
        if pd.isna(atr) or atr <= 0:
            continue
        
        whale_pct, whale_delta = get_whale_at_time(i)
        
        # Find nearby levels - include ALL for training (model will learn which are good)
        min_strength = 0.5 if (equal_count + double_count) < 10 else 0.7
        
        nearby_lows = [
            (idx, price, ltype, strength)
            for idx, price, ltype, strength in liq_levels['lows']
            if idx < i and i - idx <= LOOKBACK_CANDLES and price < current_price
            and strength >= min_strength
        ]
        
        nearby_highs = [
            (idx, price, ltype, strength)
            for idx, price, ltype, strength in liq_levels['highs']
            if idx < i and i - idx <= LOOKBACK_CANDLES and price > current_price
            and strength >= min_strength
        ]
        
        # Process LONG opportunities (sweep lows)
        for level_idx, level_price, level_type, level_strength in nearby_lows[-3:]:
            distance_atr = (current_price - level_price) / atr
            
            if distance_atr > 3:  # Too far
                continue
            
            # Get outcome
            outcome = label_trade_outcome(df, i, level_price, 'LONG', atr)
            if outcome is None:
                continue
            
            # Extract features
            hist_df = df.iloc[max(0, i-50):i+1]
            features = extract_quality_features(
                hist_df, level_price, level_type, level_strength,
                'LONG', whale_pct, whale_delta
            )
            
            if features is None:
                continue
            
            sample = {
                'symbol': symbol,
                'direction': 'LONG',
                'level_type': level_type,
                'level_strength': level_strength,
                **features,
                **outcome
            }
            samples.append(sample)
        
        # Process SHORT opportunities (sweep highs)
        for level_idx, level_price, level_type, level_strength in nearby_highs[-3:]:
            distance_atr = (level_price - current_price) / atr
            
            if distance_atr > 3:
                continue
            
            outcome = label_trade_outcome(df, i, level_price, 'SHORT', atr)
            if outcome is None:
                continue
            
            hist_df = df.iloc[max(0, i-50):i+1]
            features = extract_quality_features(
                hist_df, level_price, level_type, level_strength,
                'SHORT', whale_pct, whale_delta
            )
            
            if features is None:
                continue
            
            sample = {
                'symbol': symbol,
                'direction': 'SHORT',
                'level_type': level_type,
                'level_strength': level_strength,
                **features,
                **outcome
            }
            samples.append(sample)
    
    print(f"[QUALITY_ML] {symbol}: Generated {len(samples)} samples")
    return samples


def _find_liquidity_levels_simple(df: pd.DataFrame, atr: float) -> Dict:
    """
    Find liquidity levels (EQUAL, DOUBLE, SWING).
    
    Self-contained - doesn't depend on other modules.
    """
    lows = []
    highs = []
    
    # Find swing points
    swing_window = 5
    
    for i in range(swing_window, len(df) - swing_window):
        # Swing low
        is_swing_low = all(df['low'].iloc[i] <= df['low'].iloc[i-j] for j in range(1, swing_window+1))
        is_swing_low = is_swing_low and all(df['low'].iloc[i] <= df['low'].iloc[i+j] for j in range(1, swing_window+1))
        
        if is_swing_low:
            lows.append((i, df['low'].iloc[i]))
        
        # Swing high
        is_swing_high = all(df['high'].iloc[i] >= df['high'].iloc[i-j] for j in range(1, swing_window+1))
        is_swing_high = is_swing_high and all(df['high'].iloc[i] >= df['high'].iloc[i+j] for j in range(1, swing_window+1))
        
        if is_swing_high:
            highs.append((i, df['high'].iloc[i]))
    
    # Cluster nearby levels
    tolerance = atr * 0.3  # Levels within 0.3 ATR are considered "equal"
    
    def cluster_levels(levels):
        if not levels:
            return []
        
        # Sort by price
        sorted_levels = sorted(levels, key=lambda x: x[1])
        
        clustered = []
        current_cluster = [sorted_levels[0]]
        
        for idx, price in sorted_levels[1:]:
            # Check if this level is close to current cluster
            cluster_price = np.mean([p for _, p in current_cluster])
            
            if abs(price - cluster_price) <= tolerance:
                current_cluster.append((idx, price))
            else:
                # Finalize current cluster
                test_count = len(current_cluster)
                avg_price = np.mean([p for _, p in current_cluster])
                latest_idx = max(idx for idx, _ in current_cluster)
                
                if test_count >= 3:
                    level_type = 'EQUAL'
                    strength = 1.0
                elif test_count == 2:
                    level_type = 'DOUBLE'
                    strength = 0.85
                else:
                    level_type = 'SWING'
                    strength = 0.5
                
                clustered.append((latest_idx, avg_price, level_type, strength))
                
                # Start new cluster
                current_cluster = [(idx, price)]
        
        # Don't forget last cluster
        if current_cluster:
            test_count = len(current_cluster)
            avg_price = np.mean([p for _, p in current_cluster])
            latest_idx = max(idx for idx, _ in current_cluster)
            
            if test_count >= 3:
                level_type = 'EQUAL'
                strength = 1.0
            elif test_count == 2:
                level_type = 'DOUBLE'
                strength = 0.85
            else:
                level_type = 'SWING'
                strength = 0.5
            
            clustered.append((latest_idx, avg_price, level_type, strength))
        
        return clustered
    
    return {
        'lows': cluster_levels(lows),
        'highs': cluster_levels(highs)
    }


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN TRAINING FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

def train_quality_model(
    symbols: List[str] = None,
    days: int = 365,
    progress_callback: callable = None
) -> Dict:
    """
    Train the quality model on historical data.
    """
    if symbols is None:
        symbols = [
            'BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT',
            'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'DOTUSDT', 'LINKUSDT',
            'MATICUSDT', 'ATOMUSDT', 'LTCUSDT', 'UNIUSDT', 'APTUSDT'
        ]
    
    def update_progress(text, pct):
        if progress_callback:
            progress_callback(text, pct)
        print(f"[QUALITY_ML] {text}")
    
    update_progress("⚡ Fetching price data...", 0.1)
    
    # Fetch data
    try:
        from core.data_fetcher import fetch_klines_parallel
        
        def fetch_progress(completed, total, symbol):
            pct = 0.1 + (completed / total) * 0.3
            update_progress(f"⚡ Fetching {symbol}... {completed}/{total}", pct)
        
        klines_data = fetch_klines_parallel(
            symbols=symbols,
            interval='4h',
            limit=min(days * 6, 1500),
            progress_callback=fetch_progress
        )
    except ImportError:
        return {'error': 'data_fetcher not available'}
    
    if not klines_data:
        return {'error': 'No data fetched'}
    
    update_progress("📊 Loading whale history...", 0.45)
    
    # Load whale history
    whale_history = {}
    try:
        whale_db = "data/whale_history.db"
        if os.path.exists(whale_db):
            import sqlite3
            conn = sqlite3.connect(whale_db)
            df_whale = pd.read_sql(
                "SELECT symbol, timestamp, whale_long_pct FROM whale_snapshots ORDER BY timestamp",
                conn
            )
            conn.close()
            
            for symbol in df_whale['symbol'].unique():
                sym_data = df_whale[df_whale['symbol'] == symbol]
                whale_history[symbol] = sym_data.to_dict('records')
            
            update_progress(f"📊 Loaded whale data for {len(whale_history)} symbols", 0.5)
    except Exception as e:
        update_progress(f"⚠️ Could not load whale history: {e}", 0.5)
    
    update_progress("🔄 Generating quality samples...", 0.55)
    
    # Generate samples
    all_samples = []
    total_symbols = len(klines_data)
    
    for idx, (symbol, df) in enumerate(klines_data.items()):
        pct = 0.55 + (idx / total_symbols) * 0.35
        update_progress(f"🔄 Processing {symbol}... {idx+1}/{total_symbols}", pct)
        
        if df is None or len(df) < 100:
            continue
        
        sym_whale = whale_history.get(symbol, [])
        samples = generate_quality_samples(df, symbol, sym_whale)
        
        all_samples.extend(samples)
        print(f"[QUALITY_ML] {symbol}: {len(samples)} samples, total: {len(all_samples)}")
    
    if len(all_samples) < 100:
        return {'error': f'Not enough samples: {len(all_samples)}'}
    
    update_progress(f"🧠 Training model on {len(all_samples)} samples...", 0.92)
    
    # Train - pass actual training days for accurate frequency calculation
    model = get_quality_model()
    metrics = model.train(all_samples, training_days=days)
    
    update_progress("✅ Training complete!", 1.0)
    
    return metrics


if __name__ == "__main__":
    # Test whale analysis
    print("\n=== Whale Analysis Tests ===")
    
    # Test 1: High and rising (bullish)
    result = analyze_whale_behavior(65, 10, 'LONG')


# ═══════════════════════════════════════════════════════════════════════════════
# EASY INTEGRATION FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

def get_quality_prediction(
    symbol: str,
    direction: str,
    level_type: str,
    level_price: float,
    current_price: float,
    atr: float,
    whale_pct: float = 50,
    whale_delta: float = 0,
    momentum: float = 0,
    volume_ratio: float = 1.0
) -> Dict:
    """
    Easy integration function for Scanner and Single Analysis.
    
    Args:
        symbol: e.g., 'BTCUSDT'
        direction: 'LONG' or 'SHORT'
        level_type: 'EQUAL_LOW', 'DOUBLE_LOW', 'SWING_LOW', etc.
        level_price: Price of the liquidity level
        current_price: Current market price
        atr: Average True Range
        whale_pct: Current whale positioning (0-100)
        whale_delta: Change in whale % from previous reading
        momentum: RSI-normalized momentum (-1 to 1)
        volume_ratio: Current volume / average volume
    
    Returns:
        {
            'probability': 0.0-1.0,
            'decision': 'STRONG_YES' | 'YES' | 'MAYBE' | 'NO',
            'take_trade': True/False,
            'expected_win_rate': 0.0-1.0,
            'expected_roi': % at 1:1 R:R,
            'reasons': [...],
            'warnings': [...]
        }
    """
    model = get_quality_model()
    
    if not model.is_trained:
        return {
            'probability': 0.5,
            'decision': 'UNKNOWN',
            'take_trade': False,
            'expected_win_rate': 0.5,
            'expected_roi': 0,
            'reasons': ['Model not trained'],
            'warnings': ['Train the Quality Model first!']
        }
    
    # Calculate distance in ATR
    if direction == 'LONG':
        distance_atr = (current_price - level_price) / atr if atr > 0 else 1.0
    else:
        distance_atr = (level_price - current_price) / atr if atr > 0 else 1.0
    
    # Determine level type score
    level_type_upper = level_type.upper()
    if 'EQUAL' in level_type_upper:
        level_type_score = 1.0
        level_strength = 1.0
    elif 'DOUBLE' in level_type_upper:
        level_type_score = 0.85
        level_strength = 0.85
    else:  # SWING
        level_type_score = 0.5
        level_strength = 0.5
    
    # Analyze whale behavior
    whale_analysis = analyze_whale_behavior(whale_pct, whale_delta, direction)
    
    # Analyze level quality
    level_analysis = analyze_level_quality(level_type, level_strength, distance_atr, direction)
    
    # Build features for model
    features = {
        'distance_atr': distance_atr,
        'momentum': momentum,
        'volume_ratio': volume_ratio,
        'volatility': 1.0,  # Default
        'whale_pct': whale_pct,
        'whale_delta': whale_delta,
        'whale_quality': whale_analysis['quality'],
        'whale_aligned': 1 if whale_analysis['aligned'] else 0,
        'whale_strong': 1 if whale_analysis['strong'] else 0,
        'whale_trap': 1 if whale_analysis['trap'] else 0,
        'whale_accumulating': 1 if whale_analysis['behavior'] == 'ACCUMULATING' else 0,
        'whale_distributing': 1 if whale_analysis['behavior'] == 'DISTRIBUTING' else 0,
        'level_type_score': level_type_score,
        'level_distance_score': level_analysis['distance_score'],
        'level_quality': level_analysis['quality'],
        'level_tradeable': 1 if level_analysis['tradeable'] else 0,
        'is_long': 1 if direction == 'LONG' else 0
    }
    
    # Get prediction
    prediction = model.predict(features)
    
    # Add reasons and warnings
    reasons = []
    warnings = []
    
    # Whale reasons
    if whale_analysis['strong']:
        reasons.append(f"🐋 Strong whale alignment ({whale_pct:.0f}%)")
    if whale_analysis['behavior'] == 'ACCUMULATING' and direction == 'LONG':
        reasons.append(f"📈 Whales accumulating (+{whale_delta:.1f}%)")
    if whale_analysis['behavior'] == 'DISTRIBUTING' and direction == 'SHORT':
        reasons.append(f"📉 Whales distributing ({whale_delta:.1f}%)")
    
    # Level reasons
    if 'EQUAL' in level_type_upper:
        reasons.append(f"⭐ Strong EQUAL level (3+ tests)")
    elif 'DOUBLE' in level_type_upper:
        reasons.append(f"✓ DOUBLE level (2 tests)")
    
    if distance_atr <= 1.0:
        reasons.append(f"🎯 Close to level ({distance_atr:.1f} ATR)")
    
    # Warnings
    if whale_analysis['trap']:
        warnings.append(f"⚠️ WHALE TRAP: {whale_pct:.0f}% but dropping {whale_delta:.1f}%!")
    if whale_analysis['behavior'] == 'ACCUMULATING' and direction == 'SHORT':
        warnings.append(f"⚠️ Shorting while whales accumulate!")
    if whale_analysis['behavior'] == 'DISTRIBUTING' and direction == 'LONG':
        warnings.append(f"⚠️ Longing while whales distribute!")
    if 'SWING' in level_type_upper:
        warnings.append(f"⚠️ Weak SWING level (single test)")
    if distance_atr > 2.0:
        warnings.append(f"⚠️ Far from level ({distance_atr:.1f} ATR)")
    
    prediction['reasons'] = reasons
    prediction['warnings'] = warnings
    prediction['whale_analysis'] = whale_analysis
    prediction['level_analysis'] = level_analysis
    
    return prediction


def format_quality_badge(prediction: Dict) -> str:
    """
    Format quality prediction as a colored badge for UI.
    
    Returns HTML string for st.markdown.
    """
    decision = prediction.get('decision', 'UNKNOWN')
    prob = prediction.get('probability', 0.5)
    
    if decision == 'STRONG_YES':
        color = '#00ff88'  # Bright green
        icon = '🔥'
    elif decision == 'YES':
        color = '#88ff00'  # Yellow-green
        icon = '✅'
    elif decision == 'MAYBE':
        color = '#ffaa00'  # Orange
        icon = '⚠️'
    else:  # NO
        color = '#ff4444'  # Red
        icon = '❌'
    
    return f"{icon} **{decision}** ({prob:.0%})"
    print(f"65% whale, +10% delta, LONG: {result['behavior']}, quality={result['quality']:.1f}")
    
    # Test 2: High but dropping (TRAP!)
    result = analyze_whale_behavior(65, -10, 'LONG')
    print(f"65% whale, -10% delta, LONG: {result['behavior']}, quality={result['quality']:.1f}, TRAP={result['trap']}")
    
    # Test 3: Low but rising (bad for short)
    result = analyze_whale_behavior(40, 8, 'SHORT')
    print(f"40% whale, +8% delta, SHORT: {result['behavior']}, quality={result['quality']:.1f}")
    
    print("\n=== Should Take Trade Tests ===")
    
    # Good LONG setup
    result = should_take_trade('EQUAL_LOW', 1.0, 1.2, 68, 5, 'LONG')
    print(f"EQUAL_LOW, whale 68% +5%: {result['decision']} (score={result['score']})")
    
    # Bad LONG setup (whale trap)
    result = should_take_trade('EQUAL_LOW', 1.0, 1.2, 65, -8, 'LONG')
    print(f"EQUAL_LOW, whale 65% -8%: {result['decision']} (score={result['score']})")
    print(f"  Red flags: {result['red_flags']}")
