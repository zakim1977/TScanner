"""
Liquidity Sequence Visualization

Shows clear timeline of:
1. What was ALREADY SWEPT (done, liquidity taken)
2. CURRENT price position
3. FRESH targets above/below (future opportunities)
4. Expected sequence of events

Uses pure Streamlit components - no raw HTML.
"""

import streamlit as st
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum


class LevelStatus(Enum):
    SWEPT = "swept"           # Already swept, liquidity taken
    CURRENT = "current"       # Price at or very near this level
    FRESH = "fresh"           # Untouched liquidity pool
    APPROACHING = "approaching"  # Price moving toward this


@dataclass
class LiquidityLevel:
    price: float
    level_type: str          # "LONG_SWEEP", "SHORT_SWEEP", "TP_TARGET", "EQUAL_HIGH", "EQUAL_LOW"
    strength: str            # "STRONG", "MODERATE", "WEAK"
    status: LevelStatus
    candles_ago: int = 0     # How many candles since formed/swept
    description: str = ""
    direction_after: str = "" # "LONG" or "SHORT" - what direction AFTER sweep


def analyze_liquidity_sequence(
    levels: List[Dict],
    current_price: float,
    recent_sweep: Dict = None,
    atr: float = 0
) -> Dict:
    """
    Analyze liquidity levels and create a clear sequence map.
    
    CRITICAL: Uses recent_sweep to properly mark swept levels
    and exclude them from NEXT targets.
    
    Handles both key formats:
    - 'is_sweep' / 'detected'
    - 'candles_since' / 'candles_ago'
    """
    # Get active sweep info - handle both key formats
    recent_sweep = recent_sweep or {}
    sweep_active = recent_sweep.get('detected', False) or recent_sweep.get('is_sweep', False)
    sweep_level = recent_sweep.get('level_swept', 0)
    sweep_direction = recent_sweep.get('direction', '')
    sweep_candles = recent_sweep.get('candles_ago', 0) or recent_sweep.get('candles_since', 0)
    
    print(f"[LIQ_SEQ] analyze: sweep_active={sweep_active}, level={sweep_level}, dir={sweep_direction}, candles={sweep_candles}")
    
    # Separate levels above and below current price
    above_levels = []
    below_levels = []
    swept_levels = []
    
    for level in levels:
        price = level.get('price', 0)
        if price <= 0:
            continue
        
        # Check if this level was swept - either from level data OR match with active sweep
        is_swept = level.get('is_swept', False)
        
        # Also check against active sweep level
        if sweep_active and sweep_level > 0:
            if abs(price - sweep_level) / sweep_level < 0.01:  # Within 1%
                is_swept = True
            
        level_data = {
            'price': price,
            'type': level.get('type', 'UNKNOWN'),
            'strength': level.get('strength', 'MODERATE'),
            'description': level.get('description', ''),
            'candles_ago': sweep_candles if is_swept else level.get('candles_ago', 0),
            'is_swept': is_swept,
            'direction_after': level.get('direction_after', '')
        }
        
        if is_swept:
            swept_levels.append(level_data)
        elif price > current_price:
            above_levels.append(level_data)
        else:
            below_levels.append(level_data)
    
    # Sort: above by price ascending (nearest first), below by price descending (nearest first)
    above_levels.sort(key=lambda x: x['price'])
    below_levels.sort(key=lambda x: x['price'], reverse=True)
    
    # CRITICAL: Next targets must be FRESH (not swept!)
    # Filter out any levels close to swept level
    fresh_below = [l for l in below_levels if not l.get('is_swept', False)]
    fresh_above = [l for l in above_levels if not l.get('is_swept', False)]
    
    next_short_target = fresh_above[0] if fresh_above else None
    next_long_target = fresh_below[0] if fresh_below else None
    
    # Build sequence
    sequence = []
    
    # Add swept levels to sequence (past events)
    for swept in swept_levels:
        sequence.append({
            'step': len(sequence) + 1,
            'status': 'DONE',
            'price': swept['price'],
            'action': f"✅ Swept {swept['type']}",
            'description': f"{swept['candles_ago']} candles ago - Liquidity TAKEN",
            'direction': swept.get('direction_after', 'LONG')
        })
    
    # Current position
    sequence.append({
        'step': len(sequence) + 1,
        'status': 'NOW',
        'price': current_price,
        'action': '📍 Current Price',
        'description': 'You are here',
        'direction': None
    })
    
    # Next targets
    if next_long_target and next_short_target:
        # Determine which is more likely based on distance
        dist_to_long = current_price - next_long_target['price']
        dist_to_short = next_short_target['price'] - current_price
        
        if dist_to_long < dist_to_short:
            # Closer to long sweep
            sequence.append({
                'step': len(sequence) + 1,
                'status': 'NEXT',
                'price': next_long_target['price'],
                'action': f"🎯 {next_long_target['type']}",
                'description': f"SWEEP FOR LONG - {next_long_target['strength']}",
                'direction': 'LONG'
            })
        else:
            # Closer to short sweep
            sequence.append({
                'step': len(sequence) + 1,
                'status': 'NEXT',
                'price': next_short_target['price'],
                'action': f"🎯 {next_short_target['type']}",
                'description': f"SWEEP FOR SHORT - {next_short_target['strength']}",
                'direction': 'SHORT'
            })
    
    return {
        'current_price': current_price,
        'swept_levels': swept_levels,
        'above_levels': above_levels,
        'below_levels': below_levels,
        'next_short_target': next_short_target,
        'next_long_target': next_long_target,
        'sequence': sequence,
        'atr': atr
    }


def render_sequence_diagram_st(sequence_data: Dict, sweep_status: Dict = None):
    """
    Render the liquidity sequence as a clear visual using Streamlit components.
    No raw HTML - pure Streamlit.
    
    CRITICAL: Shows swept levels with AGE and distinguishes from FRESH targets
    
    Handles both key formats:
    - 'is_sweep' / 'detected'
    - 'candles_since' / 'candles_ago'
    """
    current_price = sequence_data.get('current_price', 0)
    above_levels = sequence_data.get('above_levels', [])
    below_levels = sequence_data.get('below_levels', [])
    swept_levels = sequence_data.get('swept_levels', [])
    next_short = sequence_data.get('next_short_target')
    next_long = sequence_data.get('next_long_target')
    
    # Get active sweep info - handle BOTH key formats
    active_sweep = sweep_status or {}
    sweep_active = active_sweep.get('detected', False) or active_sweep.get('is_sweep', False)
    sweep_level = active_sweep.get('level_swept', 0)
    sweep_candles = active_sweep.get('candles_ago', 0) or active_sweep.get('candles_since', 0)
    sweep_direction = active_sweep.get('direction', '')
    
    st.markdown("### 🗺️ Liquidity Sequence Map")
    
    # ═══════════════════════════════════════════════════════════════
    # SECTION 0: ACTIVE SWEEP STATUS (Most Important!)
    # ═══════════════════════════════════════════════════════════════
    if sweep_active and sweep_level > 0:
        st.markdown("#### ✅ Active Sweep Status")
        
        # Determine freshness
        if sweep_candles <= 3:
            freshness_emoji = "🟢"
            freshness_text = "FRESH - Entry window OPEN!"
            freshness_color = "success"
        elif sweep_candles <= 10:
            freshness_emoji = "🟡"
            freshness_text = "AGING - Consider limit order at retest"
            freshness_color = "warning"
        else:
            freshness_emoji = "🔴"
            freshness_text = "OLD - Entry window CLOSED"
            freshness_color = "error"
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Swept Level", f"${sweep_level:,.2f}")
        with col2:
            st.metric("Candles Ago", f"{sweep_candles}")
        with col3:
            st.metric("Direction", f"→ {sweep_direction}")
        
        # Status message
        if freshness_color == "success":
            st.success(f"{freshness_emoji} **{freshness_text}**")
        elif freshness_color == "warning":
            st.warning(f"{freshness_emoji} **{freshness_text}**")
        else:
            st.info(f"{freshness_emoji} **{freshness_text}** - Wait for retest or next sweep")
        
        st.divider()
    
    # ═══════════════════════════════════════════════════════════════
    # SECTION 1: SHORT TARGETS (Above Current Price)
    # ═══════════════════════════════════════════════════════════════
    st.markdown("#### 🔴 SHORT Targets (Above)")
    
    if above_levels:
        for i, level in enumerate(reversed(above_levels[:4])):
            is_next = (next_short and level['price'] == next_short['price'])
            
            col1, col2, col3, col4 = st.columns([2, 2, 1, 1])
            
            with col1:
                if is_next:
                    st.markdown(f"**🎯 ${level['price']:,.2f}**")
                else:
                    st.write(f"${level['price']:,.2f}")
            
            with col2:
                strength_emoji = "🔥" if level['strength'] == 'STRONG' else "⚡" if level['strength'] == 'MODERATE' else "•"
                st.caption(f"{strength_emoji} {level['type']}")
            
            with col3:
                if is_next:
                    st.success("NEXT")
                else:
                    dist_pct = (level['price'] - current_price) / current_price * 100
                    st.caption(f"+{dist_pct:.1f}%")
            
            with col4:
                st.write("→ SHORT")
    else:
        st.caption("No short targets above")
    
    # ═══════════════════════════════════════════════════════════════
    # SECTION 2: CURRENT PRICE (You Are Here)
    # ═══════════════════════════════════════════════════════════════
    st.divider()
    
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.info(f"📍 **CURRENT: ${current_price:,.2f}**")
    
    st.divider()
    
    # ═══════════════════════════════════════════════════════════════
    # SECTION 3: LONG TARGETS (Below Current Price)
    # Check if level matches active sweep - mark as SWEPT not NEXT!
    # ═══════════════════════════════════════════════════════════════
    st.markdown("#### 🟢 LONG Targets (Below)")
    
    if below_levels:
        for i, level in enumerate(below_levels[:4]):
            level_price = level['price']
            
            # Check if this level was swept (match within 1%)
            is_swept = False
            if sweep_active and sweep_direction == 'LONG' and sweep_level > 0:
                if abs(level_price - sweep_level) / sweep_level < 0.01:
                    is_swept = True
            
            # Also check the is_swept flag from the level data
            if level.get('is_swept', False):
                is_swept = True
            
            is_next = (next_long and level_price == next_long['price'] and not is_swept)
            
            col1, col2, col3, col4 = st.columns([2, 2, 1, 1])
            
            with col1:
                if is_swept:
                    st.markdown(f"~~${level_price:,.2f}~~")
                elif is_next:
                    st.markdown(f"**🎯 ${level_price:,.2f}**")
                else:
                    st.write(f"${level_price:,.2f}")
            
            with col2:
                if is_swept:
                    st.caption(f"✅ SWEPT ({sweep_candles} candles ago)")
                else:
                    strength_emoji = "🔥" if level['strength'] == 'STRONG' else "⚡" if level['strength'] == 'MODERATE' else "•"
                    st.caption(f"{strength_emoji} {level['type']}")
            
            with col3:
                if is_swept:
                    if sweep_candles <= 3:
                        st.success("ENTRY OPEN")
                    elif sweep_candles <= 10:
                        st.warning("AGING")
                    else:
                        st.caption("DONE")
                elif is_next:
                    st.success("NEXT")
                else:
                    dist_pct = (current_price - level_price) / current_price * 100
                    st.caption(f"-{dist_pct:.1f}%")
            
            with col4:
                if not is_swept:
                    st.write("→ LONG")
                else:
                    st.write("✓")
    else:
        st.caption("No long targets below")


def render_expected_sequence_st(sequence_data: Dict, whale_bias: str = "NEUTRAL"):
    """
    Render the expected sequence of events based on current state.
    """
    current_price = sequence_data.get('current_price', 0)
    swept_levels = sequence_data.get('swept_levels', [])
    next_short = sequence_data.get('next_short_target')
    next_long = sequence_data.get('next_long_target')
    
    st.markdown("### 📊 Expected Sequence")
    
    # Determine most likely path based on whale bias
    if whale_bias == "BULLISH" or (swept_levels and swept_levels[-1].get('direction_after') == 'LONG'):
        # Bullish scenario - swept lows, going up
        st.markdown("**Scenario: Bullish Continuation** (Whales swept lows, targeting shorts)")
        
        steps = []
        
        # Step 1: Recent sweep (done)
        if swept_levels:
            last_sweep = swept_levels[-1]
            steps.append(f"1️⃣ ✅ **Swept ${last_sweep['price']:,.2f}** - LONG liquidity taken ({last_sweep.get('candles_ago', 0)} candles ago)")
        
        # Step 2: Current
        steps.append(f"2️⃣ 📍 **Current ${current_price:,.2f}** - You are here")
        
        # Step 3: Next targets
        if next_short:
            steps.append(f"3️⃣ 🎯 **Target ${next_short['price']:,.2f}** - SHORT liquidations (TP zone)")
            
            # Find higher targets
            above = sequence_data.get('above_levels', [])
            if len(above) > 1:
                steps.append(f"4️⃣ ⚡ **Potential ${above[1]['price']:,.2f}** - More short liquidity")
        
        for step in steps:
            st.write(step)
        
        # Action box
        st.success("**Action:** Hold LONG or wait for pullback to swept level for entry")
        
    elif whale_bias == "BEARISH":
        # Bearish scenario
        st.markdown("**Scenario: Bearish Continuation** (Whales distributing, targeting longs)")
        
        steps = []
        steps.append(f"1️⃣ 📍 **Current ${current_price:,.2f}** - You are here")
        
        if next_long:
            steps.append(f"2️⃣ 🎯 **Target ${next_long['price']:,.2f}** - LONG liquidations (sweep target)")
        
        for step in steps:
            st.write(step)
        
        st.error("**Action:** Look for SHORT entries or wait for LONG sweep")
        
    else:
        # Neutral - show both scenarios
        st.markdown("**Two Scenarios Possible:**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**🟢 If Bullish:**")
            if next_short:
                st.write(f"1. Current ${current_price:,.2f}")
                st.write(f"2. Target ${next_short['price']:,.2f}")
                st.caption("Enter LONG, target short liquidity")
        
        with col2:
            st.markdown("**🔴 If Bearish:**")
            if next_long:
                st.write(f"1. Current ${current_price:,.2f}")
                st.write(f"2. Sweep ${next_long['price']:,.2f}")
                st.caption("Wait for LONG sweep, then enter")


def render_actionable_summary_st(sequence_data: Dict, sweep_status: Dict = None):
    """
    Render clear, actionable summary of what to do.
    Shows sweep age prominently with clear entry guidance.
    
    Handles both key formats:
    - 'is_sweep' / 'detected'
    - 'candles_since' / 'candles_ago'
    """
    current_price = sequence_data.get('current_price', 0)
    swept_levels = sequence_data.get('swept_levels', [])
    next_short = sequence_data.get('next_short_target')
    next_long = sequence_data.get('next_long_target')
    
    # Get active sweep info - handle BOTH key formats
    active_sweep = sweep_status or {}
    sweep_active = active_sweep.get('detected', False) or active_sweep.get('is_sweep', False)
    sweep_level = active_sweep.get('level_swept', 0)
    sweep_candles = active_sweep.get('candles_ago', 0) or active_sweep.get('candles_since', 0)
    sweep_direction = active_sweep.get('direction', '')
    
    st.markdown("### 🎯 Action Summary")
    
    if sweep_active and sweep_level > 0:
        # We have an active sweep
        st.markdown(f"**Current Setup:** {sweep_direction} entry from sweep at ${sweep_level:,.2f}")
        
        # Age metrics
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Sweep Level", f"${sweep_level:,.2f}")
        with col2:
            st.metric("Age", f"{sweep_candles} candles")
        with col3:
            # Entry window status
            if sweep_candles <= 3:
                st.metric("Window", "🟢 OPEN")
            elif sweep_candles <= 10:
                st.metric("Window", "🟡 CLOSING")
            else:
                st.metric("Window", "🔴 CLOSED")
        
        st.divider()
        
        # Clear action based on age
        if sweep_candles <= 3:
            st.success(f"🎯 **FRESH SWEEP!** Enter {sweep_direction} now")
            st.write("**Optimal entry window (1-3 candles)**")
            st.write(f"• Entry: Market order at ${current_price:,.2f}")
            st.write(f"• Stop Loss: Below ${sweep_level:,.2f}")
            if sweep_direction == 'LONG' and next_short:
                st.write(f"• Take Profit: ${next_short['price']:,.2f} (short liquidations)")
                
        elif sweep_candles <= 10:
            st.warning(f"⏰ **SWEEP AGING** ({sweep_candles} candles)")
            st.write("**Entry window closing - use limit order**")
            st.write("")
            st.write("**Options:**")
            st.write(f"1. ⏳ Set limit order at ${sweep_level:,.2f} (wait for retest)")
            st.write(f"2. 🎯 Reduced size market entry (higher risk)")
            st.write(f"3. ⏭️ Skip and wait for next sweep")
            
            if sweep_direction == 'LONG' and next_short:
                st.write("")
                st.write(f"**If already in {sweep_direction}:** TP at ${next_short['price']:,.2f}")
                
        else:
            st.info(f"🔴 **SWEEP OLD** ({sweep_candles} candles ago)")
            st.write("**Entry window CLOSED - do NOT chase!**")
            st.write("")
            st.write("**Options:**")
            st.write(f"1. ⏳ Set limit at ${sweep_level:,.2f} for retest entry")
            st.write(f"2. 👀 Wait for next fresh sweep")
            
            # Show next targets
            if sweep_direction == 'LONG':
                if next_short:
                    st.write(f"3. 📈 If in trade, TP at ${next_short['price']:,.2f}")
                if next_long and next_long['price'] < sweep_level:
                    st.write(f"4. 🎯 Next LONG sweep target: ${next_long['price']:,.2f}")
            else:
                if next_long:
                    st.write(f"3. 📉 If in trade, TP at ${next_long['price']:,.2f}")
                if next_short and next_short['price'] > sweep_level:
                    st.write(f"4. 🎯 Next SHORT sweep target: ${next_short['price']:,.2f}")
    else:
        # No active sweep - waiting mode
        st.info("👀 **WAITING MODE** - No active sweep")
        st.write("Monitor for sweeps at these levels:")
        st.write("")
        
        if next_long:
            st.write(f"🟢 **LONG opportunity:** Price sweeps below ${next_long['price']:,.2f}")
            st.caption(f"   {next_long['strength']} level - Enter LONG after sweep + rejection")
        
        if next_short:
            st.write(f"🔴 **SHORT opportunity:** Price sweeps above ${next_short['price']:,.2f}")
            st.caption(f"   {next_short['strength']} level - Enter SHORT after sweep + rejection")
        
        st.divider()
        st.caption("💡 **Tip:** Set price alerts at these levels to catch sweeps in real-time")


def render_full_liquidity_sequence(
    levels: List[Dict],
    current_price: float,
    sweep_status: Dict = None,
    whale_bias: str = "NEUTRAL",
    atr: float = 0
):
    """
    Main function to render the complete liquidity sequence visualization.
    
    Call this from app.py to display the full sequence map.
    """
    # Analyze the sequence
    sequence_data = analyze_liquidity_sequence(
        levels=levels,
        current_price=current_price,
        recent_sweep=sweep_status,
        atr=atr
    )
    
    # Render each section
    with st.expander("🗺️ **Liquidity Sequence Map** - What happens next?", expanded=True):
        
        # Tab layout for different views
        tab1, tab2, tab3 = st.tabs(["📊 Sequence", "🎯 Action", "📈 Expected Path"])
        
        with tab1:
            render_sequence_diagram_st(sequence_data, sweep_status)
        
        with tab2:
            render_actionable_summary_st(sequence_data, sweep_status)
        
        with tab3:
            render_expected_sequence_st(sequence_data, whale_bias)
