"""
Liquidity Sequence Visualization V2 - UNIFIED MODEL

Shows:
1. ACTIVE SWEEP with candles age
2. Swept levels (strikethrough)
3. Fresh targets with ML PROBABILITY
4. No trading modes - ONE model for all!
"""

import streamlit as st
from typing import Dict, List

# Import unified ML model
try:
    from liquidity_hunter.unified_lh_ml import predict_level, get_model_status, extract_features
    UNIFIED_ML_AVAILABLE = True
    print("[LIQ_SEQ] Unified ML model loaded!")
except ImportError:
    UNIFIED_ML_AVAILABLE = False
    print("[LIQ_SEQ] Unified ML not available, using rule-based")


def render_full_liquidity_sequence(
    levels: List[Dict],
    current_price: float,
    sweep_status: Dict = None,
    whale_bias: str = "NEUTRAL",
    atr: float = 0,
    whale_pct: float = 50,
    whale_delta: Dict = None
):
    """
    Main entry point - renders complete liquidity sequence.
    
    Args:
        whale_pct: Current whale long percentage
        whale_delta: Dict with whale_delta, retail_delta, lookback_label from get_whale_delta()
    """
    sweep_status = sweep_status or {}
    whale_delta = whale_delta or {}
    
    # Extract sweep info
    sweep_detected = (
        sweep_status.get('detected', False) or 
        sweep_status.get('is_sweep', False)
    )
    sweep_level = sweep_status.get('level_swept', 0)
    sweep_candles = sweep_status.get('candles_ago', 0) or sweep_status.get('candles_since', 0)
    sweep_direction = sweep_status.get('direction', '')
    
    # Extract whale delta
    whale_change = whale_delta.get('whale_delta', None)
    retail_change = whale_delta.get('retail_delta', None)
    lookback_label = whale_delta.get('lookback_label', '24h')
    
    with st.expander("🗺️ **Liquidity Sequence Map** - What happens next?", expanded=True):
        
        tab1, tab2, tab3 = st.tabs(["📊 Sequence", "🎯 Action", "📈 Path"])
        
        with tab1:
            _render_sequence_tab(
                levels, current_price, 
                sweep_detected, sweep_level, sweep_candles, sweep_direction,
                whale_pct, whale_change, lookback_label, atr
            )
        
        with tab2:
            _render_action_tab(
                levels, current_price,
                sweep_detected, sweep_level, sweep_candles, sweep_direction,
                whale_pct, whale_change
            )
        
        with tab3:
            _render_path_tab(
                levels, current_price,
                sweep_detected, sweep_level, sweep_candles, sweep_direction,
                whale_bias, whale_pct, atr
            )


def _render_sequence_tab(
    levels: List[Dict], 
    current_price: float,
    sweep_detected: bool,
    sweep_level: float,
    sweep_candles: int,
    sweep_direction: str,
    whale_pct: float = 50,
    whale_change: float = None,
    lookback_label: str = '24h',
    atr: float = 0
):
    """Render the sequence tab with levels above/below and ML probabilities."""
    
    st.markdown("### 🗺️ Liquidity Sequence")
    
    # ═══════════════════════════════════════════════════════════════
    # WHALE DELTA DISPLAY
    # ═══════════════════════════════════════════════════════════════
    if whale_change is not None:
        whale_emoji = "🟢 ↑" if whale_change > 0 else "🔴 ↓" if whale_change < 0 else "⚪ →"
        whale_color = "#00ff88" if whale_change > 0 else "#ff6b6b" if whale_change < 0 else "#888"
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric(
                label=f"Whales ({lookback_label})",
                value=f"{whale_pct:.0f}% Long",
                delta=f"{whale_change:+.1f}%" if whale_change else None,
                delta_color="normal"
            )
        with col2:
            # Whale momentum interpretation
            if whale_change and whale_change > 3:
                st.success("🐋 Whales ACCUMULATING")
            elif whale_change and whale_change < -3:
                st.error("🐋 Whales DISTRIBUTING")
            else:
                st.info("🐋 Whales HOLDING")
        
        st.divider()
    
    # ═══════════════════════════════════════════════════════════════
    # ACTIVE SWEEP STATUS BOX
    # ═══════════════════════════════════════════════════════════════
    if sweep_detected and sweep_level > 0:
        st.markdown("#### ✅ ACTIVE SWEEP")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Level", f"${sweep_level:,.2f}")
        with col2:
            st.metric("Age", f"{sweep_candles} candles")
        with col3:
            st.metric("Direction", sweep_direction)
        
        # Freshness indicator
        if sweep_candles <= 3:
            st.success("🟢 **FRESH** - Entry window OPEN!")
        elif sweep_candles <= 10:
            st.warning("🟡 **AGING** - Consider limit order at retest")
        else:
            st.error("🔴 **OLD** - Entry window CLOSED - Wait for retest or next sweep")
        
        st.divider()
    else:
        st.info("👀 No active sweep - Monitoring levels")
        st.divider()
    
    # ═══════════════════════════════════════════════════════════════
    # Separate levels into above/below current price
    # ═══════════════════════════════════════════════════════════════
    above_levels = []
    below_levels = []
    
    for level in levels:
        price = level.get('price', 0)
        if price <= 0:
            continue
        if price > current_price:
            above_levels.append(level)
        else:
            below_levels.append(level)
    
    # Sort
    above_levels.sort(key=lambda x: x.get('price', 0))  # Nearest first
    below_levels.sort(key=lambda x: x.get('price', 0), reverse=True)  # Nearest first
    
    # ═══════════════════════════════════════════════════════════════
    # ML PROBABILITY - Uses UNIFIED Model (No trading modes!)
    # ═══════════════════════════════════════════════════════════════
    def calc_target_probability(target_price: float, direction: str, level_type: str = 'LIQ_POOL', level_strength: str = 'MODERATE') -> Dict:
        """
        Calculate probability of reaching target based on DISTANCE ONLY.
        
        NO BONUSES = NO INVERSIONS POSSIBLE.
        Level quality is shown in the label, not the probability.
        """
        if current_price <= 0 or target_price <= 0 or atr <= 0:
            return {'sweep_prob': 50, 'target_prob': 50, 'combined_prob': 25, 'quality': 'UNKNOWN'}
        
        # Pure distance formula: 80 - (distance% × 5)
        pct_distance = abs(target_price - current_price) / current_price * 100
        combined_prob = int(max(15, 80 - (pct_distance * 5)))
        
        # Quality based on distance only
        if combined_prob >= 65:
            quality = 'HIGH'
        elif combined_prob >= 45:
            quality = 'MEDIUM'
        else:
            quality = 'LOW'
        
        return {
            'sweep_prob': combined_prob,
            'target_prob': combined_prob,
            'combined_prob': combined_prob,
            'quality': quality
        }
    
    # ═══════════════════════════════════════════════════════════════
    # SHORT TARGETS (Above) with ML Probability
    # Filter OUT swept levels - they're no longer valid targets!
    # ═══════════════════════════════════════════════════════════════
    st.markdown("#### 🔴 SHORT Targets (Above)")
    
    # Only show UNSWEPT levels as targets
    fresh_above_levels = [l for l in above_levels if not l.get('is_swept', False) and l.get('type', '') != 'Swept Level']
    swept_above_levels = [l for l in above_levels if l.get('is_swept', False) or l.get('type', '') == 'Swept Level']
    
    if fresh_above_levels:
        for i, level in enumerate(fresh_above_levels[:4]):
            price = level.get('price', 0)
            level_type = level.get('type', 'Pool')
            level_strength = level.get('strength', 'MODERATE')
            is_first = (i == 0)
            
            # Get ML probability
            prob_result = calc_target_probability(price, 'SHORT', level_type, level_strength)
            combined_prob = prob_result.get('combined_prob', 50)
            quality = prob_result.get('quality', 'MEDIUM')
            
            col1, col2, col3, col4 = st.columns([2.5, 1.5, 1, 1])
            with col1:
                if is_first:
                    st.markdown(f"**🎯 ${price:,.2f}**")
                else:
                    st.write(f"${price:,.2f}")
            with col2:
                st.caption(level_type)
            with col3:
                # ML Probability with color based on quality
                prob_emoji = "🟢" if quality == 'HIGH' else "🟡" if quality == 'MEDIUM' else "🔴"
                st.write(f"{prob_emoji} {combined_prob}%")
            with col4:
                if is_first:
                    st.success("NEXT")
                else:
                    pct = (price - current_price) / current_price * 100
                    st.caption(f"+{pct:.1f}%")
        
        # Show swept levels as crossed out (for context)
        if swept_above_levels:
            st.caption("~~Already swept:~~")
            for level in swept_above_levels[:2]:
                price = level.get('price', 0)
                st.caption(f"~~${price:,.2f}~~")
    else:
        if swept_above_levels:
            st.warning("All nearby levels already swept! Next target is farther.")
            for level in swept_above_levels[:2]:
                price = level.get('price', 0)
                st.caption(f"~~${price:,.2f}~~ (swept)")
        else:
            st.caption("No short targets")
    
    # ═══════════════════════════════════════════════════════════════
    # CURRENT PRICE
    # ═══════════════════════════════════════════════════════════════
    st.divider()
    st.info(f"📍 **CURRENT: ${current_price:,.2f}**")
    st.divider()
    
    # ═══════════════════════════════════════════════════════════════
    # LONG TARGETS (Below) with ML Probability
    # ═══════════════════════════════════════════════════════════════
    st.markdown("#### 🟢 LONG Targets (Below)")
    
    found_next = False
    
    if below_levels:
        for level in below_levels[:4]:
            price = level.get('price', 0)
            level_type = level.get('type', 'Pool')
            level_strength = level.get('strength', 'MODERATE')
            
            # Check if swept
            is_swept = False
            if sweep_detected and sweep_level > 0 and price > 0:
                diff_pct = abs(price - sweep_level) / sweep_level
                if diff_pct < 0.015:
                    is_swept = True
            if level.get('is_swept', False):
                is_swept = True
            
            is_next = False
            if not is_swept and not found_next:
                is_next = True
                found_next = True
            
            # Get ML probability (only for non-swept levels)
            if not is_swept:
                prob_result = calc_target_probability(price, 'LONG', level_type, level_strength)
                combined_prob = prob_result.get('combined_prob', 50)
                quality = prob_result.get('quality', 'MEDIUM')
            else:
                combined_prob = 0
                quality = 'DONE'
            
            col1, col2, col3, col4 = st.columns([2.5, 1.5, 1, 1])
            
            with col1:
                if is_swept:
                    st.markdown(f"~~${price:,.2f}~~")
                elif is_next:
                    st.markdown(f"**🎯 ${price:,.2f}**")
                else:
                    st.write(f"${price:,.2f}")
            
            with col2:
                if is_swept:
                    st.caption(f"✅ SWEPT ({sweep_candles}c)")
                else:
                    st.caption(level_type)
            
            with col3:
                if is_swept:
                    st.write("—")
                else:
                    prob_emoji = "🟢" if quality == 'HIGH' else "🟡" if quality == 'MEDIUM' else "🔴"
                    st.write(f"{prob_emoji} {combined_prob}%")
            
            with col4:
                if is_swept:
                    if sweep_candles <= 3:
                        st.success("FRESH!")
                    elif sweep_candles <= 10:
                        st.warning("AGING")
                    else:
                        st.error("OLD")
                elif is_next:
                    st.success("NEXT")
                else:
                    pct = (current_price - price) / current_price * 100
                    st.caption(f"-{pct:.1f}%")
    else:
        st.caption("No long targets")


def _render_action_tab(
    levels: List[Dict],
    current_price: float,
    sweep_detected: bool,
    sweep_level: float,
    sweep_candles: int,
    sweep_direction: str,
    whale_pct: float = 50,
    whale_change: float = None
):
    """Render action recommendations."""
    
    st.markdown("### 🎯 Action Summary")
    
    # Whale context
    if whale_change is not None:
        whale_emoji = "🟢 ↑" if whale_change > 0 else "🔴 ↓" if whale_change < 0 else "⚪ →"
        whale_status = "ACCUMULATING" if whale_change > 3 else "DISTRIBUTING" if whale_change < -3 else "HOLDING"
        st.caption(f"🐋 Whales: {whale_pct:.0f}% Long ({whale_change:+.1f}% change) - {whale_status}")
    
    if sweep_detected and sweep_level > 0:
        st.markdown(f"**Active Setup:** {sweep_direction} from sweep at ${sweep_level:,.2f}")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Swept Level", f"${sweep_level:,.2f}")
        with col2:
            st.metric("Candles Ago", f"{sweep_candles}")
        with col3:
            if sweep_candles <= 3:
                st.metric("Window", "🟢 OPEN")
            elif sweep_candles <= 10:
                st.metric("Window", "🟡 CLOSING")
            else:
                st.metric("Window", "🔴 CLOSED")
        
        st.divider()
        
        if sweep_candles <= 3:
            st.success(f"✅ **ENTER {sweep_direction} NOW** - Fresh sweep!")
            st.write(f"• Market entry at ${current_price:,.2f}")
            st.write(f"• Stop loss below ${sweep_level:,.2f}")
            
        elif sweep_candles <= 10:
            st.warning(f"⚠️ **ENTRY WINDOW CLOSING** ({sweep_candles} candles)")
            st.write("**Options:**")
            st.write(f"1. Set limit order at ${sweep_level:,.2f} (retest)")
            st.write(f"2. Reduced position size at market")
            st.write(f"3. Wait for next sweep")
            
        else:
            st.error(f"❌ **TOO LATE** - Sweep was {sweep_candles} candles ago")
            st.write("**Do NOT chase! Options:**")
            st.write(f"1. Set limit at ${sweep_level:,.2f} for retest")
            st.write("2. Wait for next fresh sweep")
            
            # Find next fresh long target
            for level in levels:
                if level.get('price', 0) < current_price and not level.get('is_swept', False):
                    if abs(level['price'] - sweep_level) / sweep_level > 0.02:  # Different level
                        st.write(f"3. Next LONG target: ${level['price']:,.2f}")
                        break
    else:
        st.info("👀 **WAITING MODE** - No active sweep")
        st.write("Monitor for sweeps at key levels below/above price")


def _render_path_tab(
    levels: List[Dict],
    current_price: float,
    sweep_detected: bool,
    sweep_level: float,
    sweep_candles: int,
    sweep_direction: str,
    whale_bias: str,
    whale_pct: float = 50,
    atr: float = 0
):
    """Render expected path/sequence."""
    
    st.markdown("### 📈 Expected Path")
    
    # Show whale context
    st.caption(f"🐋 Whale Positioning: {whale_pct:.0f}% Long ({whale_bias})")
    
    if sweep_detected and sweep_direction == 'LONG':
        st.markdown("**Bullish Scenario** (Long sweep active)")
        
        # Find FRESH targets above (filter out swept levels!)
        targets_above = [l for l in levels 
                        if l.get('price', 0) > current_price 
                        and not l.get('is_swept', False)
                        and l.get('type', '') != 'Swept Level']
        targets_above.sort(key=lambda x: x.get('price', 0))
        
        st.write(f"1️⃣ ✅ Swept ${sweep_level:,.2f} ({sweep_candles} candles ago)")
        st.write(f"2️⃣ 📍 Current ${current_price:,.2f}")
        
        if targets_above:
            level_type = targets_above[0].get('type', 'Liquidity Pool')
            st.write(f"3️⃣ 🎯 Target ${targets_above[0]['price']:,.2f} ({level_type})")
            if len(targets_above) > 1:
                level_type2 = targets_above[1].get('type', 'Liquidity Pool')
                st.write(f"4️⃣ ⚡ Extended ${targets_above[1]['price']:,.2f} ({level_type2})")
        else:
            st.caption("No fresh targets above - all nearby levels swept")
        
        st.success("**Direction:** LONG until targets hit")
        
    elif sweep_detected and sweep_direction == 'SHORT':
        st.markdown("**Bearish Scenario** (Short sweep active)")
        
        # Find FRESH targets below (filter out swept levels!)
        targets_below = [l for l in levels 
                        if l.get('price', 0) < current_price
                        and not l.get('is_swept', False)
                        and l.get('type', '') != 'Swept Level']
        targets_below.sort(key=lambda x: x.get('price', 0), reverse=True)
        
        st.write(f"1️⃣ ✅ Swept ${sweep_level:,.2f} ({sweep_candles} candles ago)")
        st.write(f"2️⃣ 📍 Current ${current_price:,.2f}")
        
        if targets_below:
            level_type = targets_below[0].get('type', 'Liquidity Pool')
            st.write(f"3️⃣ 🎯 Target ${targets_below[0]['price']:,.2f} ({level_type})")
        else:
            st.caption("No fresh targets below - all nearby levels swept")
        
        st.error("**Direction:** SHORT until targets hit")
        
    else:
        st.markdown("**Neutral - Waiting for Sweep**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**If Bullish:**")
            targets_below = [l for l in levels 
                           if l.get('price', 0) < current_price
                           and not l.get('is_swept', False)]
            if targets_below:
                targets_below.sort(key=lambda x: x.get('price', 0), reverse=True)
                st.write(f"Wait for sweep of ${targets_below[0]['price']:,.2f}")
                st.write("Then enter LONG")
        
        with col2:
            st.markdown("**If Bearish:**")
            targets_above = [l for l in levels 
                           if l.get('price', 0) > current_price
                           and not l.get('is_swept', False)]
            if targets_above:
                targets_above.sort(key=lambda x: x.get('price', 0))
                st.write(f"Wait for sweep of ${targets_above[0]['price']:,.2f}")
                st.write("Then enter SHORT")


# For backwards compatibility
def analyze_liquidity_sequence(levels, current_price, recent_sweep=None, atr=0):
    """Stub for compatibility - actual analysis done in render functions."""
    return {
        'current_price': current_price,
        'above_levels': [l for l in levels if l.get('price', 0) > current_price],
        'below_levels': [l for l in levels if l.get('price', 0) < current_price],
        'swept_levels': [l for l in levels if l.get('is_swept', False)],
        'next_short_target': None,
        'next_long_target': None,
        'sequence': [],
        'atr': atr
    }
